import React from 'react';
import "./Anasayfa.css";
import Hero from "../components/Hero";
import AfetTurleri from "../components/AfetTurleri";
import Baglantilar from "../components/Baglantilar";
import Misyonumuz from "../components/Misyonumuz";


function Anasayfa({ detayAc }) {
  return (
    <div className="ana-kisim">
      {/* footer app.jsxte çağırdığımdan dolayı burda yazmadım */}
      <Hero />
      <Misyonumuz />
      <AfetTurleri detayAc={detayAc} />
      <Baglantilar />
    </div>
  );
}

export default Anasayfa;