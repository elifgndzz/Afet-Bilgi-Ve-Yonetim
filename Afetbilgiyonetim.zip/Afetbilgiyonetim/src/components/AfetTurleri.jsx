import React from 'react'; 
import "./AfetTurleri.css"; 
import deprem from "../assets/deprem2.jpg";
import yangin from "../assets/yangin.jpg";
import Cig from "../assets/cig.jpg";
import Firtina from "../assets/firtina.jpg";
import Heyelan from "../assets/heyelan.jpg";
import Hortum from "../assets/hortum2.jpg";
import Kuraklik from "../assets/kuraklik.jpg";
import Patlama from "../assets/patlama.jpg";
import Sel from "../assets/sel.jpg";

// detayAc fonksiyonunu Anasayfa üzerinden prop olarak al
// slug:teknik isim demektir.
function AfetTurleri({ detayAc }) {
  
  // SABİT VERİ LİSTESİ: Kartlarda görünecek temel bilgiler listesi
  const afetler = [
    { id: 1, slug: "deprem", baslik: "Deprem", img: deprem, aciklama: "Sarsıntı anında ve sonrasında doğru adımlar." },
    { id: 2, slug: "sel", baslik: "Sel", img: Sel, aciklama: "Su taşkınlarına karşı hazırlık planları." },
    { id: 3, slug: "kuraklik", baslik: "Kuraklık", img: Kuraklik, aciklama: "Su tasarrufu ve sürdürülebilir yöntemler." },
    { id: 4, slug: "patlama", baslik: "Volkanik Patlama", img: Patlama, aciklama: "Magma faaliyetlerine karşı korunma yolları." },
    { id: 5, slug: "yangin", baslik: "Yangın", img: yangin, aciklama: "Orman ve ev yangınlarına karşı önlemler." },
    { id: 6, slug: "cig", baslik: "Çığ", img: Cig, aciklama: "Kar kütlelerine karşı güvenli alan tespiti." },
    { id: 7, slug: "heyelan", baslik: "Heyelan", img: Heyelan, aciklama: "Toprak kayması riski olan bölgelerde tedbirler." },
    { id: 8, slug: "hortum", baslik: "Hortum", img: Hortum, aciklama: "Şiddetli rüzgarlardan korunma yöntemleri." },
    { id: 9, slug: "firtina", baslik: "Fırtına", img: Firtina, aciklama: "Fırtınaya karşı yapısal önlemler." }
  ];

  return (
    <div id="afetler-alani" className="afet-bolumu">
      <h2 className="anasayfa-bolum-basligi">Afet Türleri</h2>
      <p className="bolum-aciklamasi">
        Hangi afete ne kadar hazırsınız? Detaylı rehberlerimizi inceleyin.
      </p>
      {/* AFET GRID: Kutuları yan yana dizen ana kutu */}
      <div className="afet-grid">

          {/* .map() FONKSİYONU: 
            Dizideki 9 afet için 9 tane 'afet-karti' kutusu oluşturur. 
            afet kelimesi o anki sıradaki kutunun tüm bilgilerini temsil eder. */}
        {afetler.map((afet) => (
          <div key={afet.id} className="afet-karti">
            <div className="resim-kutusu">
              <img src={afet.img} className="afet-resim" alt={afet.baslik} />
            </div>
            {/* YAZI VE BUTON ALANI */}
            <div className="kart-icerik">
              <h3>{afet.baslik}</h3>
              <p>{afet.aciklama}</p>

           
              <a 
                href="#" 
                className="incele-btn"
                onClick={(e) => {
                  e.preventDefault(); // Sayfanın yenilenmesiı engeller
                  detayAc(afet.slug); // App.jsx içindeki secilenAfet'i günceller
                }}
                style={{ textDecoration: 'none' }}
              >
                İncele
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AfetTurleri;