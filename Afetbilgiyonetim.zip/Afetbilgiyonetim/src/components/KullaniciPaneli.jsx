import React, { useState } from 'react';
import CantaSekmesi, { baslangicMaddeleri } from './Canta'; // Başlangıç listesini buradan çektik
import Oyunlar  from './Oyun';
import Alan from './Alan';
import RiskProfil from './RiskProfil';
import Panel from './Panel'; 
import './KullaniciPaneli.css';

function KullaniciPaneli({ setAktifSayfa }) {
  const [aktifSekme, setAktifSekme] = useState('panel');

  //  Maddelerin durumunu panel seviyesinde tut
  const [maddeler, setMaddeler] = useState(baslangicMaddeleri);

  // YÜZDE HESAPLAMA: Üst bileşende canlı hesaplanıyor ve alt bileşenlere dağıtılıyor
  const tamamlananlar = maddeler.filter(m => m.tamam).length;
  const cantaYuzdesi = Math.round((tamamlananlar / maddeler.length) * 100);

  return (
    <div className="panel-kutu">
      
      {/* SOL MENÜ (Sidebar) KISMI */}
      <div className="yan-menu">
        <div className="logo-alani">
          <div className="baslik-grubu">
            <h2 className="ust-baslik">Güvenli Yarınlar</h2>
            <p className="alt-baslik">AFET HAZIRLIK PORTALI</p>
          </div>
        </div>

        <nav className="nav-listesi">
          <div 
            className={`menu-oge ${aktifSekme === 'panel' ? 'aktif' : ''}`} 
            onClick={() => setAktifSekme('panel')}
          >
            🏠 Anasayfa
          </div>

          <div 
            className={`menu-oge ${aktifSekme === 'canta' ? 'aktif' : ''}`} 
            onClick={() => setAktifSekme('canta')}
          >
            🎒 Acil Durum Çantası
          </div>

          <div 
            className={`menu-oge ${aktifSekme === 'oyunlar' ? 'aktif' : ''}`} 
            onClick={() => setAktifSekme('oyunlar')}
          >
            🧩 Oyunlar & Quizler
          </div>

          <div 
            className={`menu-oge ${aktifSekme === 'toplanma' ? 'aktif' : ''}`} 
            onClick={() => setAktifSekme('toplanma')}
          >
            📍 Toplanma Alanları
          </div>

          <div 
            className={`menu-oge ${aktifSekme === 'risk' ? 'aktif' : ''}`} 
            onClick={() => setAktifSekme('risk')}
          >
            📈 Risk Profili
          </div>
        </nav>

        <div className="menu-alt-bolum">
          <div className="menu-oge" onClick={() => setAktifSekme('ayarlar')}>
            ⚙️ Ayarlar
          </div>
          <div className="menu-oge cikis-butonu" onClick={() => setAktifSayfa('anasayfa')}>
            🚪 Çıkış Yap
          </div>
        </div>
      </div>

      {/* SAĞ İÇERİK ALANI */}
      <div className="ana-icerik">
        {/* PANEL'e canlı yüzde durumunu prop olarak gönderiyoruz */}
        {aktifSekme === 'panel' && (
          <Panel cantaOrani={cantaYuzdesi} />
        )}

        {/* CANTA'ya state yönetimini ve hesaplanan yüzdeyi prop olarak paslıyoruz */}
        {aktifSekme === 'canta' && (
          <CantaSekmesi 
            maddeler={maddeler} 
            setMaddeler={setMaddeler} 
            yuzde={cantaYuzdesi} 
          />
        )}
        
        {aktifSekme === 'oyunlar' && <Oyunlar />}
        {aktifSekme === 'toplanma' && <Alan />} 
        {aktifSekme === 'risk' && <RiskProfil />} 
      </div>

    </div>
  );
}

export default KullaniciPaneli;