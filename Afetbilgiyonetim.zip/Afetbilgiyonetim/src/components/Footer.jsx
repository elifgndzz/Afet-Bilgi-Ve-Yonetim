import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="ana-footer">
      {/* ANA KUTU */}
      <div id="iletisim" className="footer-ust"> 
        
        {/*ACİL DURUM 112 NUMARASI */}
        <div className="footer-sutun acil-durum">
          <h3>ACİL DURUM HATTI</h3>
          <div className="acil-numara">112</div>
          <p>Tüm acil durumlar için tek numara.</p>
        </div>

        {/* İLETİŞİM */}
        <div className="footer-sutun">
          <h3>İletişim Bilgileri</h3>
          <p>📧 afetbilgi@gmail.com</p>
          <p>📍 İstanbul, Türkiye</p>
        </div>

        {/* SOSYAL MEDYA HESAPLARIM */}
        <div className="footer-sutun">
          <h3>Bizi Takip Edin</h3>
          <div className="sosyal-linkler">
            <a 
              href="https://www.instagram.com/elifecegndzz" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              Instagram
            </a>
            <a 
              href="https://github.com/elifgndzz" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              GitHub
            </a>
            <a 
              href="https://www.linkedin.com/in/elif-gündüz-29102a336" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              LinkedIn
            </a>
          </div>
        </div>
      </div> 

      {/* COPYRIGHT VE EĞİTİM PROJESİ NOTUM  */}
      <div className="footer-alt">
        <div className="alt-icerik">
          <p>© 2026 Afet Bilinci. Tüm Hakları Saklıdır. | Elif GÜNDÜZ</p>
          <p className="egitim-notu">Bu web sitesi bir <b>eğitim projesi</b> kapsamında hazırlanmıştır.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;