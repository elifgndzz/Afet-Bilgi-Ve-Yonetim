import React, { useState } from 'react';
import './Giris.css';

function Giris({ setAktifSayfa }) {
 // isLogin: Ekranın "Giriş" mi yoksa "Kayıt" modunda mı olduğunu belirler.
  const [isLogin, setIsLogin] = useState(true);
  // email ve şifreyi başta boş getir ve tut
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [yukleniyor, setYukleniyor] = useState(false); // Yükleniyor durumu için
  const [hataMesaji, setHataMesaji] = useState(''); // Girdi doğrulama hataları için

  // GİRDİ DOĞRULAMA FONKSİYONU 
  const formDogrula = () => {
    // Şifre kuralları: 
    // En az 4 karakter
    // En az 1 rakam
    const rakamKontrol = /\d/; // Regex: Rakam var mı?
    // Eğer şifre uzunluğu 4'ten küçükse hata mesajını göster
    if (password.length < 4) {
      setHataMesaji("Şifre en az 4 karakter olmalıdır!");
      return false;
    }
    // Şifre içinde rakam var mı kontrolü.
    if (!rakamKontrol.test(password)) {
      setHataMesaji("Şifre en az 1 adet rakam içermelidir!");
      return false;
    }
    // Tüm şartlar sağlandıysa hata mesajını sil ve true döndür.
    setHataMesaji(""); // Hata yoksa temizle
    return true;
  };

  // --- EVENT HANDLER: FORM GÖNDERME ---
  // form gönderme olayını yöneten fonksiyon
  const handleSubmit = (e) => {
    e.preventDefault(); // e.preventDefault():sayfayı yenileme davranışını durdurur.
    
    // Form doğrulamasını çalıştır
    if (!formDogrula()) return;

    setYukleniyor(true); // Yükleniyor durumunu başlat 

    
    setTimeout(() => {
      if (isLogin) {
        // GİRİŞ MANTIĞI
        // LocalStorage'dan daha önce kaydedilen kullanıcıyı çağır.
        const kayitliKullanici = JSON.parse(localStorage.getItem('kullanici'));
//  Eğer kayıtlı kullanıcı emaili ve şifresi aynıysa console.log a yazıdr ve giriş yap.
        if (kayitliKullanici && kayitliKullanici.email === email && kayitliKullanici.password === password) {
          console.log("✅ Giriş İşlemi Başarılı!"); // Console'a yazdırma
          alert('Başarıyla giriş yapıldı!');
          setAktifSayfa('panel');
        } else {
          // Aynı değilse hata mesajı gönder ve console 'a yazdır
          setHataMesaji("E-posta veya şifre hatalı!");
          console.error("❌ Giriş Başarısız: Hatalı bilgiler.");
        }
      } else {
        // KAYIT MANTIĞI:Yeni kullanıcı email ve şifresini alıp localStroge'ta tut 
        const kullaniciVerisi = { email, password };
        localStorage.setItem('kullanici', JSON.stringify(kullaniciVerisi));

        alert('Kayıt başarılı! Giriş yapabilirsiniz.');
        setIsLogin(true);
      }
      setYukleniyor(false); // İşlem bitince yükleniyor durumunu kapat
    }, 1500);
  };

  return (
    <div className="giris-kutusu">
      <div className="giris-kart">
        {/* TERNARY OPERATÖR:İslogin e göre başlığı değiştir. */}
        <h2>{isLogin ? 'Giriş Yap' : 'Üye Ol'}</h2>

        {/* Hata Mesajı Gösterimi */}
        {hataMesaji && <div className="hata-kutusu">{hataMesaji}</div>}
        
        {/* onSubmit: Form gönderildiğinde handleSubmit çalışır */}
        <form onSubmit={handleSubmit}>
          
          <div className="input-grubu">
            <label>E-posta</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              placeholder="ornek@mail.com"
              required 
            />
            {/* required:doldurulması zorunlu alan,boş gönderilmez */}
          </div>

          <div className="input-grubu">
            <label>Şifre</label>
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              placeholder="••••••"
              required 
            />
          </div>

          {/* Yükleniyor Durumu Gösterimi: Buton metni duruma göre değişir */}
          <button type="submit" className="giris-buton" disabled={yukleniyor}>
            {yukleniyor ? 'İşlem yapılıyor...' : (isLogin ? 'Giriş Yap' : 'Kaydol')}
          </button>
        </form>

        {/* onClick: Kayıt ve Giriş ekranları arasında geçiş yapar */}
        <p className="giris-link" onClick={() => { setIsLogin(!isLogin); setHataMesaji(""); }}>
          {isLogin ? 'Hesabın yok mu? Üye Ol' : 'Zaten üye misin? Giriş Yap'}
        </p>
      </div>
    </div>
  );
}

export default Giris;