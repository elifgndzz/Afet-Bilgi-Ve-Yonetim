import React, { useState, useEffect } from 'react';
import './Misyonumuz.css';

// STATE (DURUM): Bileşenin ekranda görünür olup olmadığını tutar.
//    Başlangıçta false (gizli).
function Misyonumuz() {
  const [gorunurMu, setGorunurMu] = useState(false);

// Sayfa kaydırma (scroll) olayını dinlemek için kullanılır
  useEffect(() => {
    const kontrolEt = () => {
     // window.scrollY: Sayfanın en tepesinden ne kadar aşağı inildiğini piksel olarak verir.
     // Eğer 400 pikselden fazla aşağı inilmişse state'i true(görünür) yap.
      const asagiInmeMiktari = window.scrollY;
      if (asagiInmeMiktari > 400) {
        setGorunurMu(true);
      } else {
        setGorunurMu(false); // Eğer tekrar yukarı çıkılırsa animasyonu başa sarmak için false yap.
        
      }
    };
// kaydırma yapıldığında kontrolEt fonksiyonunu çalıştır diyoruz.
    window.addEventListener('scroll', kontrolEt);

    // başka sayfaya geçilirse kaydırmayı kontrol etmeyi bırakıyoruz.
    return () => window.removeEventListener('scroll', kontrolEt);
  }, []);

  return (
    <section 
      /* Eğer gorunurMu true ise 'hareket-vakti' classını cssde taasarla değilse boş bırak. */
      className={`misyon-yazi ${gorunurMu ? 'hareket-vakti' : ''}`}
    >
      <div className="misyon-kapsayici">
        {/* Başlık Bölümü */}
        <div id="misyonumuz" className="misyon-header">
          <span className="etiket">VİZYON & MİSYON</span>
          <h2 className="dev-baslik">
            Afetlere karşı <span>hazır</span> , bilgiyle <span>güvende</span> bir gelecek.
          </h2>
        </div>
{/* Liste Bölümü: 01, 02, 03 şeklinde sıralı maddeler */}
        <div className="misyon-liste-yeni">
          <div className="misyon-satir">
            <span className="satir-no">01</span>
            <div className="satir-icerik">
              <h3>Toplumsal Farkındalık</h3>
              <p>Afet farkındalığını her bireye ulaştırarak, toplumun en güçlü halkası olmanızı hedefliyoruz.</p>
            </div>
          </div>

          <div className="misyon-satir">
            <span className="satir-no">02</span>
            <div className="satir-icerik">
              <h3>Hızlı Erişim Kanalları</h3>
              <p>En doğru bilgiyi, en sade ve hızlı şekilde ulaştıran bir köprü kuruyoruz.</p>
            </div>
          </div>

          <div className="misyon-satir">
            <span className="satir-no">03</span>
            <div className="satir-icerik">
              <h3>Sürekli Güncellik</h3>
              <p>Teknolojiyi merkeze alarak sürekli güncellenen, dinamik bir rehber sunuyoruz.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

export default Misyonumuz;