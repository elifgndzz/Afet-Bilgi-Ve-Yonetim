import React from 'react';
import HeyelanHaritasi from '../assets/HeyelanHaritasi.png';
import RiskHaritasi from '../assets/RiskBolge.png'; 
import AfetYerlesim from '../assets/AfetYerlesim.png';
// portalda tıklanınca açılan resimlerimi başta import ettim.assets klasörüne koydum.

function PortalDetay({ icerik, kapatFonksiyonu }) {
  // içerik boş gelirse uygulama çökmesin diye YÜKLENİYOR yazısı
    if (!icerik) return <div>Yükleniyor...</div>;
  return (
    <div className="portal-kutu">
      {/* kullanıcıyı anasayfaya döndüren buton */}
      <button onClick={kapatFonksiyonu} className="geri-btn">⬅ Geri Dön</button>
      
      {icerik === 'heyelan' && (
        <div className="detay-izgara">
          {/* HARİTA KUTUSUNU GÖSTER */}
          <div className="detay-kutu harita-alani">
            <h3>Türkiye Heyelan Duyarlılık Haritası</h3>
            <img src={HeyelanHaritasi} alt="Heyelan Haritası" className="gorsel" />
          </div>

          {/* ALT KISIMDA BİLGİ KUTUSU */}
          <div className="detay-kutu analiz-alani">
            <h4>📊 Teknik Analiz</h4>
            <p>AFAD verilerine göre Türkiye topraklarının %25'i heyelan riski altındadır.</p>
          </div>

          {/* KAYNAK KUTUSU */}
          <div className="detay-kutu kaynak-alani">
            <h4>ℹ️ Kaynak</h4>
            <p>Bu veriler AFAD 2024 Heyelan Envanter Raporu'ndan alınmıştır.</p>
          </div>
        </div>
      )}

      {icerik === 'risk-bolgeleri' && (
  <div className="detay-izgara">
    {/* SOL BÜYÜK KUTU: Harita */}
    <div className="detay-kutu harita-alani">
      <h3>Türkiye Deprem ve Afet Risk Bölgeleri</h3>
      <img src={RiskHaritasi} alt="Afet Risk Haritası" className="gorsel" />
    </div>

    {/* SAĞ ÜST KUTU: Analiz */}
    <div className="detay-kutu analiz-alani">
      <h4>📊 Harita Analizi</h4>
      <p>Bu harita; diri fay hatlarını, I. ve II. derece deprem bölgelerini ve Kızılay lojistik merkezlerini eş zamanlı gösterir.</p>
    </div>

    {/* SAĞ ALT KUTU: Detaylar */}
    <div className="detay-kutu kaynak-alani">
      <h4>⚠️ Kritik Notlar</h4>
      <p>Haritada görülen siyah noktalar kaya düşmesi, turuncu alanlar ise heyelan duyarlılığını temsil eder.</p>
    </div>
  </div>
)}
{/*Afet Risk Bölgeleri Seçildiyse */}
{icerik === 'zarar' && (
  <div className="detay-izgara">
    
    {/* SOL BÜYÜK KUTU: Harita */}
    <div className="detay-kutu harita-alani">
      <h3>{icerik === 'risk-bolgeleri' && (
  <div className="detay-izgara">
    {/* SOL BÜYÜK KUTU: Harita */}
    <div className="detay-kutu harita-alani">
      <h3>Türkiye Deprem ve Afet Risk Bölgeleri</h3>
      <img src={RiskHaritasi} alt="Afet Risk Haritası" className="gorsel" />
    </div>

    {/* SAĞ ÜST KUTU: Analiz */}
    <div className="detay-kutu analiz-alani">
      <h4>📊 Harita Analizi</h4>
      <p>Bu harita; diri fay hatlarını, I. ve II. derece deprem bölgelerini ve Kızılay lojistik merkezlerini eş zamanlı gösterir.</p>
    </div>

    {/* SAĞ ALT KUTU: Detaylar */}
    <div className="detay-kutu kaynak-alani">
      <h4>⚠️ Kritik Notlar</h4>
      <p>Haritada görülen siyah noktalar kaya düşmesi, turuncu alanlar ise heyelan duyarlılığını temsil eder.</p>
    </div>
  </div>
)}</h3>
      <img src={RiskHaritasi} alt="Afet Risk Haritası" className="gorsel" />
    </div>

    {/* SAĞ ÜST KUTU: Analiz */}
    <div className="detay-kutu analiz-alani">
      <h4>📊 Harita Analizi</h4>
      <p>Bu harita; diri fay hatlarını, I. ve II. derece deprem bölgelerini ve Kızılay lojistik merkezlerini eş zamanlı gösterir.</p>
    </div>

    {/* SAĞ ALT KUTU: Detaylar */}
    <div className="detay-kutu kaynak-alani">
      <h4>⚠️ Kritik Notlar</h4>
      <p>Haritada görülen siyah noktalar kaya düşmesi, turuncu alanlar ise heyelan duyarlılığını temsil eder.</p>
    </div>
  </div>
)}
    </div>
  );
}

export default PortalDetay;