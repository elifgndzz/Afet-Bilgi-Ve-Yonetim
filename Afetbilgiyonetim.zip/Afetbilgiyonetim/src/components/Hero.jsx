import React from 'react';
import './Hero.css'; 
import hortum from "../assets/hero3.png";
import cevre from "../assets/hero1.png";
import deprem from "../assets/hero2.png";

function Hero() {
  return (
    <div id="anasayfa" className="hero-bolumu">
      {/* Üst Kısım: Başlık ve Resimler */}
      <div className="hero-ana-icerik">
        <div className="sol-taraf">
          <h1>Afet Bilinci</h1>
          <p>Hazırlıklı olmak hayat kurtarır. Bilinçli bir toplum ve güvenli yarınlar için gelin, birlikte hazırlanalım.</p>
        </div>

        <div className="sag-taraf">
          <img src={hortum} alt="hortum" className="resim-stil" />
          <img src={cevre} alt="cevre" className="resim-stil" />
          <img src={deprem} alt="deprem" className="resim-stil" />
        </div>
      </div>
      </div>
);
}

export default Hero;