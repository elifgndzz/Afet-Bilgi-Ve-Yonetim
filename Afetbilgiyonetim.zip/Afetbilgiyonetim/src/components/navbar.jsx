import React from 'react';
import ataturk from "../assets/ataturk.png";
import "./navbar.css";

//  buton diye fonksiyon tanımla ve basıldığında giris.jsx sayfasına gitsin.
function Buton({ setAktifSayfa}) {
  return (
    <button 
      className="giris-btn" 
      onClick={() => setAktifSayfa('giris')} 
    >
      Giriş Yap
    </button>
  );
}

// setAktifSayfa sayfalar arası geçişi kontrol eder setportaliçeriği ise hangi bilginin yükleneceğini tutar
function Navbar({ setAktifSayfa, setPortalIcerigi }) {
  return (
    <nav className="navbar">
      <ul className="nav">
        <li><a href="#anasayfa">Anasayfa</a></li>
        
        <li className="menu">
          <a href="#afetler-alani">Afet Türleri</a>
        </li>
 {/* BİLGİ PORTALI YAPISI:Sol tarafta tanım sağ tarafta ise kategoriler ve linkler yer alır. */}
         <li className="genis-menu-kapsayici">
          <a href="#">Bilgi Portalı</a>
          <div className="acilir-buyuk-menu">
            <div className="menu-ic-alan">
              <div className="sol-tanitim">
                <h3>Bilgi Portalı</h3>
                <p>Güncel haritalar ve detaylı analiz raporlarına ulaşabileceğiniz kapsamlı dijital kütüphanemiz.</p>
              </div>

              <div className="sag-link-listesi">
                <ul className="ana-kategoriler">
                  <li className="alt-menulu-baslik">
                    <a href="#" onClick={(e) => e.preventDefault()}>Afet Haritaları</a>
                    <ul className="yandaki-alt-liste">
                      <li>
                         {/* EVENT (OLAY):Tıklandığında sayfanın yenilenmesini engelleyip heyelan adlı içeriği göster. */}
                         {/* diğer linkleri de aynı mantıkla yaptım */}
                        <a href="#" onClick={(e) => { e.preventDefault(); setAktifSayfa('portal'); setPortalIcerigi('heyelan'); }}>
                          Türkiye Heyelan Haritası
                        </a>
                      </li>
                      <li>
                       <a href="#" onClick={(e) => { e.preventDefault(); setAktifSayfa('portal'); setPortalIcerigi('risk-bolgeleri');}}>
                                                      Türkiye Deprem ve Afet Risk Bölgeleri
                                               </a>
                      </li>
                      <li>
                        <a href="#" onClick={(e) => { e.preventDefault(); setAktifSayfa('portal'); setPortalIcerigi('zarar'); }}>
                         Türkiye Afete Uğramış Yerleşim Birimleri Haritası
                                          (1950 - 2008)
                        </a>
                      </li>
                    </ul>
                  </li>

                  <li className="alt-menulu-baslik">
                    <a href="#" onClick={(e) => e.preventDefault()}>Afet Raporları</a>
                    <ul className="yandaki-alt-liste">
                      <li>
                        <a href="https://www.afad.gov.tr/afet-analiz" 
                                target="_blank"  // Yeni sekmede açar.
                                 rel="noreferrer">
                          Afet Analiz Raporları
                        </a>
                      </li>
                      <li>
                        <a href="https://www.afad.gov.tr/afet-istatistikleri"target='blank' rel='noreferrer'>
                       Afet İstatistikleri
                        </a>
                      </li>
                    </ul>
                  </li>

                  <li className="alt-menulu-baslik">
                    <a href="#" onClick={(e) => e.preventDefault()}>Afet Takip Merkezi</a>
                    <ul className="yandaki-alt-liste">
                      <li>
                        {/* KANDİLLİ RASATHANESİ SON DEPREMLER */}
                        <a href="http://www.koeri.boun.edu.tr/scripts/lst0.asp" target="_blank" rel="noreferrer"> 
                          Son Depremler (Kandilli)
                        </a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </li>
         {/* navbarın geri kalan kısımları üzerine tıklanınca anasayfada ilgili bölüme gider. */}
        <li><a href="#misyonumuz">Misyonumuz</a></li>
        <li><a href="#baglantilar">Bağlantılar</a></li>
        <li><a href="#iletisim">İletişim</a></li>
      </ul>
                 {/* ATATÜRK Resmi */}
      <div className="sag-alan">
        <Buton setAktifSayfa={setAktifSayfa} />
        <div className="atam">
          <img src={ataturk} alt="Atatürk" />
        </div>
      </div>
    </nav>
  );
}

export default Navbar;