import React, { useState } from 'react';
import './cerezBildirimi.css';

function CerezBildirimi() {
  const [gorunur, setGorunur] = useState(true);

  // Butona basınca bildirim kapansın
  if (!gorunur) return null;

  return (
    <div className="cerez-cerceve">
      <div className="cerez-ic-alan">
        {/* SOL TARAF: Metinler */}
        <div className="cerez-metin-tarafi">
          <h3>Bu site çerez kullanmaktadır.</h3>
          <p>
            Bu site, çevrimiçi deneyiminizi iyileştirmek için çerezler kullanmaktadır. 
            Çerezleri nasıl kullandığımız hakkında daha fazla bilgi edinmek için lütfen 
            <span className="link"> kullanım koşullarımıza</span> bakın.
          </p>
        </div>

        {/* SAĞ TARAF: Buton */}
        <div className="cerez-buton-tarafi">
          <button className="cerez-btn" onClick={() => setGorunur(false)}>
            Kabul Et ve Kapat
          </button>
        </div>

        {/* KAPATMA İKONU*/}
        <button className="cerez-kapat" onClick={() => setGorunur(false)}>
          ✕
        </button>
      </div>
    </div>
  );
}

export default CerezBildirimi;