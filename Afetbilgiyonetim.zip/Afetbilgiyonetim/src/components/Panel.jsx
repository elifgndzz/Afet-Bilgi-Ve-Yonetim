import React, { useEffect, useState } from 'react'; // React ile birlikte sayfa ilk açıldığında değişken veri yapmak için useEffect kullandım.
import './Panel.css'; 
 //ANASAYFA SEKMESİ
// Dışarıdan (yani KullaniciPaneli.jsx dosyasından) gelen çanta doluluk yüzdesini "props" yöntemiyle, yani süslü parantez içinde { cantaOrani } şeklinde buraya teslim alıyoruz.
function Panel({ cantaOrani }) {
  const toplamOyunPuani = 480; // Quizlerden kazanılan ve ekranda sabit duracak olan başarı puanı değeri
  const [veriDurumu, setVeriDurumu] = useState('⏳ AFAD Merkezinden güncel veriler senkronize ediliyor...');

  useEffect(() => {
    // setTimeout: Sayfa tarayıcıda ilk kez açıldığında arkada 1.5 saniyelik bir geri sayım başlat
    const zamanlayici = setTimeout(() => {
      // 1.5 saniye süre dolduğu an, veriDurumu isimli yazımızı otomatik olarak bu yeşil onaylı metne dönüştür.set fonksiyonunu güncelle
      setVeriDurumu('✅ AFAD Standart Verileri Başarıyla Güncellendi.');
    }, 1500);

    //  Eğer kullanıcı bu sayfa tam yüklenmeden hızlıca başka bir sekmeye geçerse,
    // arkada dönen zamanlayıcıyı siler (clearTimeout)
    // () =>:Arrow fonksiyonu
    return () => clearTimeout(zamanlayici);
  }, []); // En sondaki boş köşeli parantez []: SADECE İLK AÇILIŞTA bir kere çalışmasını sağlar.

  return (
    <div className="ana-panel-kutu">
      
      {/* SOL ALAN: KUTUSUZ, DÜZ METİN VE SIRALI LİSTELERDEN OLUŞAN BÖLÜM */}
      <div className="sol-liste-alani">
        <h1 className="büyük-karsılama-baslik">Merhaba 👋</h1>
        <p className="alt-aciklama-metni">Afet hazırlık durumunuzu ve portal aktivitelerinizi buradan takip edebilirsin.</p>
        
        {/* DINAMIK YAZDIRMA: useEffect'ten gelen ve 1.5 saniye sonra güncellenen canlı durum yazısını süslü parantez ile buraya basıyoruz */}
        <p className="useeffect-canli-notu">{veriDurumu}</p>
        
        {/* SIRALI LİSTE SİSTEMİ */}
        <div className="dikey-liste-grubu">
          
          {/* Çanta Durumu Göstergesi */}
          <div className="satir-grup">
            <div className="satir-sol-simge">
              <div className="simge-daire canta-arka-plan">🎒</div>
              <div className="ortadaki-baglanti-cizgisi"></div>
            </div>
            <div className="satir-sag-metin">
              <span className="kucuk-grup-etiketi">Çanta Durumu</span>
              {/* Dışarıdan gelen 'cantaOrani' props değerini süslü parantez ile al. */}
              <h4>Acil durum çantanız %{cantaOrani} oranında hazır.</h4>
              <p>Maddeleri tamamlayarak hazırlık seviyenizi artırabilirsiniz.</p>
              
              {/* Çizgisel Yüklenme Çubuğu (Progress Bar) */}
              <div className="düz-ilerleme-cubugu">
                {/* Genişlik (width) değerini inline-style kullanarak çantadan gelen canlı yüzdeye eşitle. 
                    Çantada ne kadar madde işaretlenirse kırmızı çizgi o kadar sağa doğru uzayacak.
                */}
                <div className="cubuk-doluluk-oranı" style={{ width: `${cantaOrani}%` }}></div>
              </div>
            </div>
          </div>

          {/* Satır 2: Oyun Skor Durumu */}
          <div className="satir-grup">
            <div className="satir-sol-simge">
              <div className="simge-daire oyun-arka-plan">🏆</div>
              <div className="ortadaki-baglanti-cizgisi"></div>
            </div>
            <div className="satir-sag-metin">
              <span className="kucuk-grup-etiketi">Eğitim & Skor</span>
              <h4>Toplam {toplamOyunPuani} başarı puanına sahipsiniz.</h4>
              <p>Quizleri çözerek "Afet Bilinçli Gönüllü" unvanını kazandınız.</p>
            </div>
          </div>

          {/* Satır 3: Haftalık Görev Durumu */}
          <div className="satir-grup">
            <div className="satir-sol-simge">
              <div className="simge-daire gorev-arka-plan">📌</div>
            </div>
            <div className="satir-sag-metin">
              <span className="kucuk-grup-etiketi">Haftalık Görev</span>
              <h4>Bina Risk Analizinizi Yapın.</h4>
              <p>Sol menüdeki Risk Profili bölümünden hızlıca test edebilirsiniz.</p>
            </div>
          </div>

        </div>
      </div>

      <div className="sag-kutular-grubu">
        {/* KUTU 1: ACİL NUMARALAR REHBERİ */}
        <div className="panel-sag-kart">
          <div className="kart-ust-baslik-yeri">
            <span className="kart-ikonu">📞</span>
            <h3>Acil Numaralar</h3>
          </div>
          <div className="numara-listesi">
            {/* span etiketi:bir kelimeyi renklendirmek şekillendirmek. */}
            <div className="numara-satiri"><strong>ACİL ÇAĞRI (İtfaiye/Ambulans/Polis):</strong> <span>112</span></div>
            <div className="numara-satiri"><strong>AFAD:</strong> <span>122</span></div>
          </div>
        </div>

        {/* KUTU 2: SOLU ŞERİTLİ KRİTİK DUYURULAR BÖLÜMÜ */}
        <div className="panel-sag-kart">
          <div className="duyuru-ana-baslik">
            <span className="duyuru-hoparlor-ikon">📢</span>
            <h3>Kritik Duyurular</h3>
          </div>
          
          <div className="duyuru-kapsayici-liste">
            <div className="duyuru-kutu-satiri yeni-icerik">
              <span className="duyuru-gunu">Bugün</span>
              <h4>🧩 Yeni Oyun Eklendi!</h4>
              <p>"Selden Kaçış" senaryo oyunu aktif edildi. Kendini test etmeye hemen başla!</p>
            </div>

            {/* Standart Gri Çizgili Duyuru */}
            <div className="duyuru-kutu-satiri">
              <span className="duyuru-gunu">Dün</span>
              <h4>🎒 Çanta Kontrol Zamanı</h4>
              <p>Gıda ve pillerin son kullanma tarihlerini altı ayda bir kontrol etmeyi unutmayın.</p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}

export default Panel;