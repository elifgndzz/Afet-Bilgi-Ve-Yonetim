import React, { useState } from 'react';
import './Alan.css';

const toplanmaAlanlari = [
  { 
    id: 1, 
    ad: "Atatürk Parkı Güvenli Alanı", 
    mesafe: "0.3 km", 
    adres: "Merkez Mahallesi, Park Sokak No: 4",
    haritaUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.97123456789!2d28.9784!3d41.0082!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDAwJzI5LjUiTiAyOMKwNTgnNDIuMiJF!5e0!3m2!1str!2str!4v1700000000000" 
  },
  { 
    id: 2, 
    ad: "Gençlik Spor Tesisi Bahçesi", 
    mesafe: "0.8 km", 
    adres: "Hürriyet Mahallesi, Spor Caddesi No: 12",
    haritaUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3009.12345678901!2d28.9830!3d41.0120!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDAwJzQzLjIiTiAyOMKwNTgnNTguOCJF!5e0!3m2!1str!2str!4v1700000000001" 
  },
  { 
    id: 3, 
    ad: "Belediye Meydanı Toplanma Noktası", 
    mesafe: "1.2 km", 
    adres: "İstiklal Caddesi, Belediye Binası Önü",
    haritaUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.85432109876!2d28.9730!3d41.0050!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDAwJzE4LjAiTiAyOMKwNTgnMjIuOCJF!5e0!3m2!1str!2str!4v1700000000002" 
  },
  { 
    id: 4, 
    ad: "Cumhuriyet İlkokulu Bahçesi", 
    mesafe: "1.5 km", 
    adres: "Fatih Mahallesi, Okul Yolu Sokak No: 3",
    haritaUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3009.32109876543!2d28.9900!3d41.0180!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDAxJzA0LjgiTiAyOMKwNTknMjQuMCJF!5e0!3m2!1str!2str!4v1700000000003" 
  }
];

function Alan() {
  //  ilk alanı haritada seçili gösteriyoruz
  const [secilenAlan, setSecilenAlan] = useState(toplanmaAlanlari[0]);

  return (
    <div className="alan-konteyner">
      <div className="alan-ust-yazi">
        <h2>Acil Durum Toplanma Alanları</h2>
        <p>Size en yakın güvenli toplanma alanlarını listeden seçerek harita üzerindeki konumunu görebilirsiniz.</p>
      </div>

      <div className="alan-icerik-paneli">
     
        <div className="alan-detay-kartlari">
          
          <div className="en-yakin-kart-etiket">🚨 EN YAKIN ALANLAR</div>
          
          <div className="alan-listesi-kapsayici">
            {/* toplanma alanlarındaki alanları ekrana getir. */}
            {toplanmaAlanlari.map((alan) => (
              <div 
              // her alanın kendi id sini ver
                key={alan.id} 
                // koşullu classname:listelenen id seçilenle eşitse
                className={`alan-liste-kart ${secilenAlan.id === alan.id ? 'secili-alan' : ''}`}
                // eğer seçili alan ile alan idler eşitse secili alan classname ekle değişlse boş bırak.
                onClick={() => setSecilenAlan(alan)}
                // kullanıcının seçtiği alan ile birlikte setsecilialan güncellenir
              >
                <div className="alan-kart-bilgi">
                  <h3>{alan.ad}</h3>
                  <p className="alan-liste-adres">{alan.adres}</p>
                </div>
                <div className="alan-liste-mesafe">{alan.mesafe}</div>
              </div>
            ))}
          </div>

        </div>

   
        <div className="harita-cerceve">
          <iframe
            title="Toplanma Alanı Haritası"
            width="100%"
            height="100%"
            style={{ border: 0, borderRadius: "20px" }}
            src={secilenAlan.haritaUrl}
            allowFullScreen
          ></iframe>
        </div>
      </div>
    </div>
  );
}

export default Alan;