import React, { useState, useEffect } from 'react';
import Heimlich from '../assets/heimlich.jpeg';
import Koma from '../assets/koma.jpg';
import Turnike from '../assets/turnike.jpg';
import './Oyun.css';
// Görselleri kolayca eşleştirebilmek için bir nesne (obje) tanımlıyoruz

const gorselEslesme = {
  heimlich: Heimlich,
  koma: Koma,
  turnike: Turnike
};

// 1. OYUN: Afet Efsaneleri
const efsaneSorular = [
  { id: 1, metin: "Deprem sırasında kapı eşikleri evin en güvenli yerleridir.", cevap: false },
  { id: 2, metin: "Asansörle hızlıca aşağı inmek sarsıntı anında en iyi tahliye yoludur.", cevap: false },
  { id: 3, metin: "Afet çantası sadece deprem bittikten sonra hazırlanmalıdır.", cevap: false },
  { id: 4, metin: "Eşyaları sabitlemek sadece eski ve dayanıksız binalarda gereklidir.", cevap: false },
  { id: 5, metin: "Deprem çantasında mutlaka düdük bulunmalıdır.", cevap: true },
  { id: 6, metin: "Küçük sarsıntılar, büyük depremin enerjisini tamamen boşaltır.", cevap: false },
  { id: 7, metin: "Deprem anında pencereleri açmak binanın esnemesine yardımcı olur.", cevap: false },
  { id: 8, metin: "Depremden hemen önce mutlaka gökyüzünde ışık çakmaları görülür.", cevap: false },
  { id: 9, metin: "Evcil hayvanların huzursuzluğu kesin deprem olacağı anlamına gelir.", cevap: false },
  { id: 10, metin: "Mutfak tezgahının altı hayat üçgeni için en güvenli yerdir.", cevap: false }
];

// 2. OYUN: Sel Senaryoları
const selSorulari = [
  {
    id: 1,
    senaryo: "Yoğun yağış başladı ve su seviyesi hızla yükseliyor. Evin hangi bölümüne geçmelisin?",
    secenekler: ["A) Bodrum Katı", "B) Çatı veya Üst Katlar", "C) Mutfak Balkonu"],
    cevap: 1
  },
  {
    id: 2,
    senaryo: "Aracınla yoldayken su seviyesi tekerleklerin yarısına ulaştı. Ne yapmalısın?",
    secenekler: ["A) Hızla içinden geçmeye çalışırım", "B) Aracın içinde beklerim", "C) Aracı terk edip yüksek bir yere çıkarım"],
    cevap: 2 
  },
  {
    id: 3,
    senaryo: "Sel uyarısı yapıldı. Evden çıkmadan önce ilk neyi kapatmalısın?",
    secenekler: ["A) Pencereleri", "B) Elektrik şalteri ve gaz vanasını", "C) Televizyonu"],
    cevap: 1
  },
  {
    id: 4,
    senaryo: "Sel suları çekildi ve eve geri döndün. Elektriği ne zaman açmalısın?",
    secenekler: ["A) Hemen açarım", "B) Tesisat kontrol edildikten sonra", "C) Sular çekildiği an"],
    cevap: 1
  }
];

// 3. OYUN: İlk Yardım Testi 
const ilkyardimSorulari = [
  {
    id: 1,
    senaryo: "Yandaki görselde boğulma işareti yapan ve nefes alamayan kişiye hangi ilk yardım manevrası uygulanmalıdır?",
    secenekler: ["A) Rentek Manevrası", "B) Heimlich Manevrası", "C) Şok Pozisyonu"],
    cevap: 1,
    gorselKey: "heimlich"
  },
  {
    id: 2,
    senaryo: "İlk yardımın öncelikli amaçlarından biri olan 'Hayati tehlikenin ortadan kaldırılması' hangi aşamaya girer?",
    secenekler: ["A) Koruma", "B) Kurtarma", "C) Bildirme"],
    cevap: 1
  },
  {
    id: 3,
    senaryo: "Yetişkin bir kişide kalp masajı yapılırken göğüs kemiği kaç cm aşağı inecek şekilde bası uygulanır?",
    secenekler: ["A) 3 cm", "B) 5 cm", "C) 8 cm"],
    cevap: 1
  },
  {
    id: 4,
    senaryo: "Bilinç kaybı olan ancak solunumu devam eden bir yaralıya hangi pozisyon verilmelidir?",
    secenekler: ["A) Koma (Kurtarma) Pozisyonu", "B) Yarı Oturuş Pozisyonu", "C) Şok Pozisyonu"],
    cevap: 0
  },
  {
    id: 5,
    senaryo: "Görseldeki gibi, kaza geçirmiş bir yaralıyı araçtan omuriliğine zarar vermeden çıkarmak için kullanılan teknik hangisidir?",
    secenekler: ["A) İtfaiyeci Yöntemi", "B) Rentek Manevrası", "C) Altın Beşik Yöntemi"],
    cevap: 1,
    gorselKey: "rentek"
  },
  {
    id: 6,
    senaryo: "Kimyasal madde yanıklarında ilk yardım olarak ne yapılmalıdır?",
    secenekler: ["A) Hemen merhem sürülmelidir", "B) En az 15-20 dakika tazyiksiz bol suyla yıkanmalıdır", "C) Yanık bölge sargı beziyle sıkıca kapatılmalıdır"],
    cevap: 1
  },
  {
    id: 7,
    senaryo: "Hangi durumda turnike (boğucu sargı) uygulanması zorunludur?",
    secenekler: ["A) Hafif sıyrıklarda", "B) Çok sayıda yaralının olduğu ortamda uzuv kopması varsa", "C) Burun kanamalarında"],
    cevap: 1
  },
  {
    id: 8,
    senaryo: "Yandaki ilk yardım görselinde gösterilen, yaralının yan yatırıldığı bu pozisyonun adı nedir?",
    secenekler: ["A) Koma Pozisyonu", "B) Şok Pozisyonu", "C) Baş-Çene Pozisyonu"],
    cevap: 0,
    gorselKey: "koma"
  },
  {
    id: 9,
    senaryo: "Kanamalarda ilk yardım uygularken, kanayan bölgeye ne yapılmalıdır?",
    secenekler: ["A) Kanayan yer kalp seviyesinden aşağıda tutulmalıdır", "B) Temiz bir bezle üzerine doğrudan baskı uygulanmalıdır", "C) Üzerine hemen alkol dökülmelidir"],
    cevap: 1
  },
  {
    id: 10,
    senaryo: "Yetişkin bir kişiye yapılan dış kalp masajında, kalp basısı ile yapay solunum oranı ne olmalıdır?",
    secenekler: ["A) 15 Kalp Masajı - 2 Suni Solunum", "B) 30 Kalp Masajı - 2 Suni Solunum", "C) 5 Kalp Masajı - 1 Suni Solunum"],
    cevap: 1
  },
  {
    id: 11,
    senaryo: "Burun kanaması olan bir kişiye hangi ilk yardım adımı uygulanmalıdır?",
    secenekler: ["A) Baş arkaya doğru itilmeli ve burun köküne basılmalıdır", "B) Baş hafifçe öne eğilmeli ve burun kanatları 5 dakika sıkılmalıdır", "C) Hasta sırt üstü yatırılmalıdır"],
    cevap: 1
  },
  {
    id: 12,
    senaryo: "Görselde uygulanan turnike işleminde, turnike yapılan bandın üzerine ne yazılması hayati önem taşır?",
    secenekler: ["A) Yaralının adresi", "B) Turnikenin uygulandığı saat ve dakika", "C) İlk yardımcının telefon numarası"],
    cevap: 1,
    gorselKey: "turnike"
  },
  {
    id: 13,
    senaryo: "Arı sokmasında, eğer derinin üzerinde arının iğnesi görünüyorsa ne yapılmalıdır?",
    secenekler: ["A) Cımbız yardımıyla deriyi ezmeden çıkarılmalıdır", "B) Üzerine çamur sürülmelidir", "C) İğne derinin içinde bırakılmalıdır"],
    cevap: 0
  },
  {
    id: 14,
    senaryo: "Sara krizi (havale) geçiren bir kişiye ilk yardımda ne yapılmalıdır?",
    secenekler: ["A) Ağzı zorla açılarak kilitlenen çene çözülmeye çalışılmalıdır", "B) Kişinin canını yakmayacak şekilde başının altına yumuşak bir şey konup krizin geçmesi beklenmelidir", "C) Tokat atılarak kendine getirilmelidir"],
    cevap: 1
  },
  {
    id: 15,
    senaryo: "Şok pozisyonunda yaralının bacakları kaç cm yukarı kaldırılmalıdır?",
    secenekler: ["A) 15 cm", "B) 30 cm", "C) 50 cm"],
    cevap: 1
  }
];

function Oyunlar() {
  const [aktifOyun, setAktifOyun] = useState(null); // 'efsaneler', 'sel' veya 'ilkyardim'
  const [mevcutSoruIndex, setMevcutSoruIndex] = useState(0);
  const [toplamPuan, setToplamPuan] = useState(0);
  const [oyunBitti, setOyunBitti] = useState(false);
  const [mesaj, setMesaj] = useState("");
  const [kartCevrildi, setKartCevrildi] = useState(false);

useEffect(() => {
    const kaydedilenPuan = localStorage.getItem('afetPuan');
    if (kaydedilenPuan) {
      setToplamPuan(parseInt(kaydedilenPuan ));
    }
   
  }, []);

  // Ortak Cevap Verme Fonksonu:Tüm oyunlarda ortak bir fonksiyon.seçilen şıkkı tutuyoruz.
  const cevapVer = (secilen) => {
    const aktifSorular = 
      aktifOyun === 'efsaneler' ? efsaneSorular : 
      aktifOyun === 'sel' ? selSorulari : ilkyardimSorulari;
// aktif soruların cevaplarını getir ve doğru cevap adı altında topla
    const dogruCevap = aktifSorular[mevcutSoruIndex].cevap;

    if (secilen === dogruCevap) {
      const yeniPuan = toplamPuan + 10;
      setToplamPuan(yeniPuan);
      localStorage.setItem('afetPuan', yeniPuan);
      // set ıtem:veriyi güncellemek.
      setMesaj("✅ DOĞRU!");
    } else {
      setMesaj("❌ YANLIŞ!");
    }

    setKartCevrildi(true);

    setTimeout(() => {
      setKartCevrildi(false);
      setMesaj(""); 
      // kartın önüne çevir ve ekrandaki mesajı kaybet
      if (mevcutSoruIndex + 1 < aktifSorular.length) {
        // mevcut sorularda sorulacak soru kaldı mı diye uzunluğunu kontrol et
        setMevcutSoruIndex(mevcutSoruIndex + 1);
      } else {
        setOyunBitti(true);
      }
    }, 1500);
  };
// aktif oyunu kapat mevcut soruyu sıfırla 
  const lobiyeDon = () => {
    setAktifOyun(null);
    setMevcutSoruIndex(0);
    setOyunBitti(false);
    setKartCevrildi(false);
  };
  const aktifSorularListesi = 
    aktifOyun === 'efsaneler' ? efsaneSorular : 
    aktifOyun === 'sel' ? selSorulari : ilkyardimSorulari;

  return (
    <div className="oyun-konteyner">
      
      {/* LOBİ EKRANI */}
      {aktifOyun === null && (
        <div className="lobi-alani">
          <div className="lobi-header">
            <h2>Oyunlar ve Quizler</h2>
            <p>Puanları topla, afet hazırlık seviyeni ölç!</p>
          </div>
          <div className="oyun-listesi">
            {/* OYUN 1 KARTI */}
            <div className="oyun-liste-kart" onClick={() => setAktifOyun('efsaneler')}>
              <h3>Afet Efsaneleri</h3>
              <p>Doğru-Yanlış testi</p>
            </div>
            {/* OYUN 2 KARTI */}
            <div className="oyun-liste-kart sel-ozel" onClick={() => setAktifOyun('sel')}>
              <h3>Selden Kaçış</h3>
              <p>Senaryo bazlı seçim oyunu</p>
            </div>
            {/* OYUN 3 KARTI (İLK YARDIM)*/}
            <div className="oyun-liste-kart ilkyardim-ozel" onClick={() => setAktifOyun('ilkyardim')}>
              <h3>Temel İlk Yardım Bilgisi</h3>
              <p>Görsel destekli, seçmeli bilgi testi</p>
            </div>
          </div>
        </div>
      )}

      {/* OYUN İÇİ EKRANI */}
      {aktifOyun !== null && (
        <div className="oyun-ici-alan">
          <div className="oyun-ust-panel">
            <button onClick={lobiyeDon}>⬅ Lobiye Dön</button>
            <div className="puan">🏆 Puan: {toplamPuan}</div>
          </div>

          {!oyunBitti ? (
            /* KART ÇEVİRME YAPISI */
            <div className={`oyun-karti-kapsayici ${kartCevrildi ? 'cevrildi' : ''}`}>
              
              {/* KARTIN ÖN YÜZÜ (SORU) */}
              <div className="kart-on">
                <span className="soru-no">
                  Soru {mevcutSoruIndex + 1} / {aktifSorularListesi.length}
                </span>
                
                {/* --- EKLEME: GÖRSEL GÖSTERİM ALANI --- */}
                {/* sorular listesinde tanımlanmış bir görsel key varsa getir. */}

                {aktifSorularListesi[mevcutSoruIndex].gorselKey && (
                  <img 
                    src={gorselEslesme[aktifSorularListesi[mevcutSoruIndex].gorselKey]} 
                    alt="Soru Görseli" 
                    className="soru-gorseli" 
                  />
                )}

                {/* 1. SEÇENEK: Afet Efsaneleri (Doğru-Yanlış):eğer efsaneler ise 2 tane buton gönder. */}
                {aktifOyun === 'efsaneler' && (
                  <>
                    <p>{efsaneSorular[mevcutSoruIndex].metin}</p>
                    <div className="buton-grubu">
                      <button onClick={() => cevapVer(true)}>DOĞRU</button>
                      <button onClick={() => cevapVer(false)}>YANLIŞ</button>
                    </div>
                  </>
                )}

                {/* 2. SEÇENEK: Sel Senaryoları (Seçmeli) */}
                {aktifOyun === 'sel' && (
                  <>
                    <p className="senaryo-metni">{selSorulari[mevcutSoruIndex].senaryo}</p>
                    <div className="secenek-listesi">
                      {selSorulari[mevcutSoruIndex].secenekler.map((s, index) => (
                        <button key={index} onClick={() => cevapVer(index)}>{s}</button>
                      ))}
                    </div>
                  </>
                )}

                {/*3. SEÇENEK: İlk Yardım Testi (Seçmeli) */}
                {aktifOyun === 'ilkyardim' && (
                  <>
                    <p className="senaryo-metni">{ilkyardimSorulari[mevcutSoruIndex].senaryo}</p>
                    <div className="secenek-listesi">
                      {ilkyardimSorulari[mevcutSoruIndex].secenekler.map((s, index) => (
                        <button key={index} onClick={() => cevapVer(index)}>{s}</button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* KARTIN ARKA YÜZÜ (SONUÇ) */}
              <div className="kart-arka">
                <div className="sonuc-mesaj">{mesaj}</div>
              </div>

            </div>
          ) : (
            <div className="sonuc-alan">
              <h3>Tebrikler! 🎉</h3>
              <p>Testi başarıyla tamamladın!</p>
              <button onClick={lobiyeDon}>Başa Dön</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Oyunlar; 