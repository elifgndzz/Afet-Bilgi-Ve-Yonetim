import React from 'react';
import './Baglantilar.css';

function Baglantilar() {
  const kurumlar = [
    { ad: "AFAD", tanim: "Afet ve Acil Durum Yönetimi", link: "https://www.afad.gov.tr", renk: "#010101" },
    { ad: "AKUT", tanim: "Arama Kurtarma Derneği", link: "https://www.akut.org.tr", renk: "#d90429" },
    { ad: "YEŞİLAY", tanim: "Sağlıklı Yaşam ve Mücadele", link: "https://www.yesilay.org.tr", renk: "#2d6a4f" },
    { ad: "TÜRK KIZILAY", tanim: "İnsani Yardım Merkezi", link: "https://www.kizilay.org.tr", renk: "#980812" }
  ];

  return (
    <section id="baglantilar"className="baglantilar-alan">
      <div className="baglantilar-ic-cerceve">
        <h2 className="liste-baslik">Resmi Kurumlar & Bağlantılar</h2>
        
        <div className="link-listesi">
          {kurumlar.map((kurum, index) => (
            <a 
              key={index}  // React'in liste takibi için kullandığı sıra numarası
              href={kurum.link} // Tıklayınca gidilecek olan web adresi
              target="_blank" //Linkin mevcut sayfayı kapatmadan YENİ SEKMEDE açılmasını sağlar. 
              rel="noreferrer"   
              className="kurum-satiri"
              style={{ "--kurum-renk": kurum.renk }}  //Burada her sitenin renginin farklı olabilmesi için CSS'e isim gönderiyoruz
            >
              <div className="satir-sol">
                <span className="kurum-isim">{kurum.ad}</span>
                <span className="kurum-aciklama">{kurum.tanim}</span>
              </div>
              <div className="satir-sag">
                <span className="git">Siteyi Ziyaret Et ↗</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Baglantilar;