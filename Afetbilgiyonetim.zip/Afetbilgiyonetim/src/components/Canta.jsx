import React from 'react';
import CantaResmi from '../assets/CantaResmi.png';
import './Canta.css';

// Başındaki export kelimesi, bu listenin başka dosyalardan da erişilebilir olmasını sağlar
export const baslangicMaddeleri = [
  { id: 1, ad: 'Kişi başı 3 litre su', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 2, ad: 'Konserve ve kuru gıda', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 3, ad: 'Enerji barları ve kuruyemiş', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 4, ad: 'Yağmurluk ve yedek kıyafet', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 5, ad: 'Termal battaniye veya uyku tulumu', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 6, ad: 'Evcil hayvanınız için temel ihtiyaçlar (mama, su, karne vb.)', kat: 'Temel İhtiyaçlar', tamam: false },
  { id: 7, ad: 'İlk yardım çantası', kat: 'Sağlık ve Hijyen', tamam: false },
  { id: 8, ad: 'Düzenli kullanılan ilaçlar', kat: 'Sağlık ve Hijyen', tamam: false },
  { id: 9, ad: 'Maske', kat: 'Sağlık ve Hijyen', tamam: false },
  { id: 10, ad: 'Diş fırçası ve macun', kat: 'Sağlık ve Hijyen', tamam: false },
  { id: 11, ad: 'Pilli radyo ve yedek piller', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 12, ad: 'El feneri', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 13, ad: 'Şarj kablosu', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 14, ad: 'Koli bandı', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 15, ad: 'Not defteri ve kalem', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 16, ad: 'Gıda saklama poşeti/Kilitli poşet', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 17, ad: 'Düdük', kat: 'Teknik Ekipmanlar', tamam: false },
  { id: 18, ad: 'Kimlik ve tapu fotokopileri', kat: 'Kritik Belgeler', tamam: false },
  { id: 19, ad: 'Sağlık kayıtları ve kan grubu bilgisi', kat: 'Kritik Belgeler', tamam: false },
  { id: 20, ad: 'Acil durum iletişim numaraları bilgisi', kat: 'Kritik Belgeler', tamam: false },
  { id: 21, ad: 'Önemli evrakların kopyası (Kimlik, pasaport, sigorta poliçesi)', kat: 'Kritik Belgeler', tamam: false },
  { id: 22, ad: 'Bir miktar nakit para', kat: 'Kritik Belgeler', tamam: false }
];
// app jsx den verileri çekiyoruz.
function CantaSekmesi({ maddeler, setMaddeler, yuzde }) {

  
  const maddeDegistir = (id) => {
    // maddeler listesindekilere bak madde id ile id eşitse tamamlanma durumunu tersine çevir
    setMaddeler(maddeler.map(m => m.id === id ? { ...m, tamam: !m.tamam } : m));
  };

  return (
    <div className="canta-konteyner">
      {/* BAŞLIK VE ORAN KARTI */}
      <div className="canta-ust-bolum">
        <div className="metin-alani">
          <h1>Acil Durum Çantası</h1>
          <p>Hayatta kalma kitini düzenli tut, eksikleri tamamla ve güvenle hazırlan.</p>
        </div>

        {/* HALKA TAMAMLANMA ORANI */}
        <div className="oran-kart">
         {/* gelen yüzde verisine göre ilerleme halkasını boya. */}
          <div className="ilerleme-halkasi" style={{ background: `conic-gradient(#dc3545 ${yuzde}%, #e0e0e0 0)` }}>
            <div className="halka-ic">{yuzde}%</div>
          </div>
          <span className="oran-metni">Tamamlama Oranı</span>
        </div>
      </div>

      <div className="canta-govde-izgara">
        {/* SOL: CHECKLIST */}
        <div className="checklist-kolonu">
          <div className="onemli-hatirlatma">
            <strong>🔴 Önemli Hatırlatma</strong>
            <p>Gıdaları 6 ayda bir kontrol ederek güncelleyin.Hazırladığınız afet çantasını çıkış kapısının yanında ve kolay ulaşılabilir bir alanda tutun.</p>
          </div>
 
          {/* 4 kategorili bir döngü oluştur  */}
          {["Temel İhtiyaçlar", "Sağlık ve Hijyen", "Teknik Ekipmanlar", "Kritik Belgeler"].map(kat => (
            <div key={kat} className="kategori-bolumu">
              <h3 className="kategori-baslik">{kat}</h3>
              {/* .filter:sadece o anki kategoriye ait olan maddeleri ekrana getir. */}
              {maddeler.filter(m => m.kat === kat).map(madde => (
                <div
                  key={madde.id}
                  /* Eğer madde tamamlandıysa CSS'te rengini ayarlamak için 'tamamlandi' ekle */
                  className={`madde-satiri ${madde.tamam ? 'tamamlandi' : ''}`}
                  onClick={() => maddeDegistir(madde.id)}
                >
                  <input type="checkbox" checked={madde.tamam} readOnly />
                  <span>{madde.ad}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* SAĞ: NEDEN ÖNEMLİ? KISMI */}
        <div className="bilgi-kolonu">
          <div className="neden-onemli-kutusu">
            <div className="ampul-ikon">💡</div>
            <h3>Neden Önemli?</h3>
            <p>Afet sonrası ilk 72 saat, dış yardıma ulaşana kadar kendi başınızasınız demektir. Sağlık kiti, küçük yaralanmaların enfeksiyona dönüşmesini önler.</p>
            <div className="kontrol-notu">
              🕒 İlaçların son kullanma tarihlerini 6 ayda bir kontrol edin.
            </div>
          </div>
        </div>
      </div>

      {/* ALT KISIM: Rehber Kartı */}
      <div className="rehber-kart">
        <div className="rehber-kart-metin">
          <h3>Çantayı Nasıl Hazırlamalısın?</h3>
          <p>
            Afet çantası sadece bir malzeme yığını değildir; Yaşam üçgenindeki en büyük destekçinizdir. Uzmanlar tarafından hazırlanan rehberimizi inceleyerek doğru yerleşimi öğrenin.
          </p>
          <a
            href="https://www.youtube.com/watch?v=K0keerAalYE"
            target="_blank"
            rel="noreferrer"
            className="video-btn"
          >
            Eğitim videosunu izle
          </a>
        </div>

        <div className="rehber-sag-resim">
          <img src={CantaResmi} alt="Çanta Hazırlığı" />
        </div>
      </div>
    </div>
  );
}

export default CantaSekmesi;