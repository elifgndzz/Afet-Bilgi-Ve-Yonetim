import React, { useState } from 'react';  
import './RiskProfil.css';  

function RiskProfil() {
//  başta hepsini boş çağırıyoruz ki ilk açıldığında seçiniz olarak gelsin
  const [binaYili, setBinaYili] = useState('');
  const [katSayisi, setKatSayisi] = useState('');
  const [tasiyiciSistem, setTasiyiciSistem] = useState('');
  const [catlakDurumu, setCatlakDurumu] = useState('');
  const [zeminKat, setZeminKat] = useState('');
  const [bodrumNem, setBodrumNem] = useState('');
  const [binaProje, setBinaProje] = useState('');
  const [asansorBakim, setAsansorBakim] = useState('');

  // hata ve sonuç mesajlarını ekranda göstermek için.başta boş gelsin.
  // hata mesajı:analiz sorularında boş kalırsa gönderilir.
  // sonuç metni:kullanıcının işaretlediği seçenekler doğrultusunda hesaplama yapılıp risk/güven oranı mesajı
  const [hataMesaji, setHataMesaji] = useState(''); 
  const [sonucMetni, setSonucMetni] = useState(''); 

  // BUTONA BASILDIĞINDA RİSK PUANINI HESAPLAYAN MATEMATİKSEL FONKSİYON
  const riskHesapla = () => {
    // Boş bırakılan soru var mı kontrolü yapılıyor
    // "!" işareti "eğer boşsa/yoksa" anlamına gelir. "||" işareti ise "VEYA" anlamına gelir.
   
    if (
      !binaYili || !katSayisi || !tasiyiciSistem || 
      !catlakDurumu || !zeminKat || !bodrumNem || 
      !binaProje || !asansorBakim
    ) {
      // eğer bunlardan birisi bile boşsa gösterilecek olan hata mesajı.
      setHataMesaji('⚠️ Lütfen hesaplama yapılabilmesi için tüm soruları cevaplayınız!');
      setSonucMetni('');
      return;
    }

    setHataMesaji(''); 
    let toplamRiskPuani = 0;

    // CEVAPLARA GÖRE HESAPLAMA
    // eğer bina yılı 99 öncesiyse risk puanı +25 ekler.
    if (binaYili === '1999-oncesi') toplamRiskPuani += 25;
    else if (binaYili === '1999-2018') toplamRiskPuani += 10;

    if (katSayisi === '7-uzeri') toplamRiskPuani += 15;
    else if (katSayisi === '4-7') toplamRiskPuani += 5;

    if (tasiyiciSistem === 'evet') toplamRiskPuani += 20;
    if (catlakDurumu === 'var') toplamRiskPuani += 15;
    if (bodrumNem === 'var') toplamRiskPuani += 10;
    if (binaProje === 'yok') toplamRiskPuani += 10;

    if (toplamRiskPuani > 95) toplamRiskPuani = 95;
    const guvenlikOrani = 100 - toplamRiskPuani;

   // güvenlik oranı:100'den risk puanını çıkardığımızda ortaya çıkan oran
    // SONUCUN DURUMUNA GÖRE EKRANA BASILACAK METNİ SEÇME:eğer risk puanı 50 den büyük eşitse risk altındasınız mesajı gelir.Değilse güvenlik oranı gelir.
    if (toplamRiskPuani >= 50) {
      setSonucMetni(`🚨 Yapılan ön değerlendirmeye göre %${toplamRiskPuani} risk altındasınız. Binanızı resmi kurumlara inceletmeniz önerilir.`);
    } else {
      setSonucMetni(`✅ Yapılan ön değerlendirmeye göre %${guvenlikOrani} güvenlisiniz. Afet hazırlıklarınızı ihmal etmeyiniz.`);
    }
  };

  return (
    <div className="risk-profil-kapsayici">
      
      {/* ÜST BAŞLIK ALANI */}
      <div className="risk-baslik">
        <h2>Risk Profili Analizi</h2>
        <p>Yaşadığınız binanın ve bölgenin afet risklerini anlamak, hazırlıklı olmanın ilk adımıdır.</p>
      </div>

      {/* ANA SAYFA DÜZENİ*/}
      <div className="risk-ana-alan">
        
        {/* SOL ANA BLOK: BİNA ANALİZİ FORMU */}
        <div className="analiz-kart risk-sol-blok">
          <h3>🏢 Bina Analizi</h3>
          {/* HER BİR FORM GRUBU BİR SORUYU TEMSİL EDER */}
          {/* select kutularındaki 'value' özelliği o an hafızada ne olduğunu gösterir. */}
            {/* 'onChange' ise kullanıcı yeni bir şeye tıkladığında 'set...' fonksiyonunu günceller. */}
          <div className="form-tasarimi">
            <div className="form-grup">
              {/* Soru 1: Yapım Yılı */}
              <label>Binanızın Yapım Yılı</label>
              <select value={binaYili} onChange={(e) => setBinaYili(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="1999-oncesi">1999 Öncesi</option>
                <option value="1999-2018">1999 - 2018 Arası</option>
                <option value="2018-sonrasi">2018 Sonrası</option>
              </select>
            </div>
                {/* Soru 2: Kat Sayısı */}
            <div className="form-grup">
              <label>Kat Sayısı</label>
              <select value={katSayisi} onChange={(e) => setKatSayisi(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="1-3">1 - 3 Kat arası</option>
                <option value="4-7">4 - 7 Kat arası</option>
                <option value="7-uzeri">7 Kat ve üzeri</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Taşıyıcı Sistemde Değişiklik</label>
              <select value={tasiyiciSistem} onChange={(e) => setTasiyiciSistem(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="hayir">Hayır / Bilinmiyor</option>
                <option value="evet">Evet (Kolon kesme vb.)</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Görünür Çatlaklar</label>
              <select value={catlakDurumu} onChange={(e) => setCatlakDurumu(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="yok">Yok</option>
                <option value="var">Var (Taşıyıcı kolon/kirişlerde)</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Zemin Kat Kullanımı</label>
              <select value={zeminKat} onChange={(e) => setZeminKat(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="konut">Konut</option>
                <option value="dukan">Dükkan / Ticarethane</option>
                <option value="o-otopark">Oto Park</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Bodrumda Nem/Korozyon</label>
              <select value={bodrumNem} onChange={(e) => setBodrumNem(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="yok">Yok</option>
                <option value="var">Var (Rutubet / Demirlerde paslanma)</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Bina Projesi Onayı</label>
              <select value={binaProje} onChange={(e) => setBinaProje(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="evet">Evet, var</option>
                <option value="yok">Hayır / Bilinmiyor</option>
              </select>
            </div>

            <div className="form-grup">
              <label>Asansör Bakım Durumu</label>
              <select value={asansorBakim} onChange={(e) => setAsansorBakim(e.target.value)}>
                <option value="">Seçiniz</option>
                <option value="duzenli">Düzenli yapılıyor</option>
                <option value="yapilmiyor">Yapılmıyor / Asansör Yok</option>
              </select>
            </div>
          </div>

          {/* HESAPLAMA BUTONU: Tıklandığında yukarıdaki riskHesapla fonksiyonunu çalıştırır. */}
          <button className="hesapla-btn" onClick={riskHesapla}>
            Risk Seviyesini Hesapla
          </button>
            {/* ekranda bir hata mesajı veya sonuç kutusu varsa onun tasarımını yapmak için buraya classname verdim */}
          {hataMesaji && <div className="risk-hata-kutusu">{hataMesaji}</div>}
          {sonucMetni && <div className="risk-sonuc-kutusu">{sonucMetni}</div>}
        </div>

        {/* SAĞ ANA BLOK: KONUM ANALİZİ BİLGİ KARTI */}
        <div className="analiz-kart risk-sag-blok">
          <h3>🌍 Konum Analizi Nasıl Yapılır?</h3>
          <p>
            Yaşadığınız bölgenin zemin yapısı, fay hatlarına yakınlığı ve heyelan riski gibi faktörler, 
            bina güvenliği kadar kritiktir. Konum bazlı profesyonel bir analiz için resmi kurumların 
            verileri temel alınmalıdır.
          </p>
          {/* AFAD'IN SİTESİNE YÖNLENDİRİLİR.AYRI SAYFADA AÇILIR. */}
          <a 
            href="https://tdth.afad.gov.tr" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="afad-link-btn"
          >
            Resmi AFAD Haritasına Git ↗
          </a>
        </div>

        {/* EN ALT BÖLÜM: YAN YANA DURAN 3 TANE KÜÇÜK BİLGİ KUTUSU */}
        <div className="analiz-kart alt-bilgi-kutusu">
          <span className="kart-simge">❓</span>
          <h4>Neden Risk Analizi Yapmalıyım?</h4>
          <p>
            Risk analizi, binanızın yapısal durumunu görmenizi sağlar. Olası bir afette hangi noktaların 
            zayıf olduğunu bilmek, doğru önlemleri almanıza ve can güvenliğinizi korunuza yardımcı olur.
          </p>
        </div>

        <div className="analiz-kart alt-bilgi-kutusu uyari-analiz-kart">
          <span className="kart-simge">📌</span>
          <h4>Önemli Not</h4>
          <p>
            Bu testte sağlanan sonuçlar, verdiğiniz cevaplar doğrultusunda hazırlanan bir <strong>ön değerlendirmedir</strong>. 
            Kesinlikle resmi bir bina analiz raporu yerine geçmez. Kesin sonuçlar için yetkili mühendislik firmalarına başvurun.
          </p>
        </div>

        <div className="analiz-kart alt-bilgi-kutusu">
          <span className="kart-simge">🔒</span>
          <h4>Gizlilik ve Güvenlik</h4>
          <p>
            <strong>Gizlilik:</strong> Bu forma girdiğiniz bina yapım yılı, kat sayısı veya adres tahminleri gibi hiçbir veri 
            veritabanımıza kaydedilmez. Analiz tamamen tarayıcınızda yapılır ve sayfayı kapattığınızda silinir.
          </p>
        </div>

      </div>
    </div>
  );
}

export default RiskProfil;