import React from 'react';
import "./AfetDetay.css";
// AFET TÜRLERİNDE SEÇİLİ AFETE BASILDIĞINDA DETAY OLARAK AÇILAN SAYFA
// afet verilerini sona yazdım
function AfetDetay(props) {
  // APP.JSX TEN GELEN TİP BİLGİSİNİ AL VE AFET VERİLERİNDEN O AFETE AİT VERİLERİ GÖSTER
  const veri = AFET_VERILERI[props.tip];

// eğer veri yoksa boş olarak göstersin
  if (!veri) return null;

  return (
    <div className="detay-sayfa-alani">
      {/* Üst Kısım-başlık ve kapat butonu */}
      <div className="ust-nav">
        <span className="baslik">AFET BİLGİ REHBERİ</span>
        {/* App.jsx'ten gelen kapat fonksiyonunu butona bağla ve basınca anasayfaya dönsün.*/}
        <button onClick={props.kapatFonksiyonu} className="kapat-btn">✕ Kapat</button>
      </div>

      {/* Giriş Bölümü:Başlık ve kısa tanım. */}
       {/* afet verilerinden seçilen başlığı ve metni al. */}
      <div className="giris-bolumu">
        <h1 className="ana-baslik">{veri.baslik}</h1>
        <p className="vurgulu-alt-baslik">{veri.altBaslik}</p>
        <div className="metin-alani">
          {/* .MAP() KULLANIMI: 'tanimlar' listesindeki her cümleyi sırayla p etiketi içine yazar */}
          {veri.tanimlar.map((paragraf, index) => (
           <p 
        key={index} 
        style={{ 
          fontWeight: index === 1 ? "bold" : "normal", 
          color: index === 1 ? "#000" : "inherit" // 1. indeksi daha koyu siyah yapar
        }}
      >
        {paragraf}
      </p>
          ))}
        </div>
      </div>

      {/* Strateji Kartları-ÖNCESİ,SIRASI,SONRASINDA BÖLÜMÜ */}
      <div className="strateji-konteyner">
        {/* stratejilerin her biri için kart oluştur */}
        {veri.stratejiler.map((kart) => (
          <div className="kartlar" key={kart.no}>
            <div className="kart-no">{kart.no}</div>
            <h3>{kart.baslik}</h3>
            {/* KARTIN İÇİNDEKİ MADDELERİ KART NO İLE BERABER HEPSİNİ TEK TEK LİSTE (Lİ)ŞEKLİNDE EKRANDA GÖSTER */}
            <ul className="madde-listesi">
              {kart.maddeler.map((madde, i) => (
                <li key={i}>{madde}</li>
                // i:sorunsuz çalışabilmesi  için
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Önemli bilgi Alanı:Her afet hakkında bir bilgi sunan kart. */}
      <div className="harita-bilgi-alani">
        <div className="harita-metni">
          <span className="ikon-buyuk">{veri.haritaIkon}</span>
          <p>{veri.haritaNotu}</p>
        </div>
      </div>

      {/* Efsaneler ve Gerçekler:Burada afet hakkında yanlış bilinenleri düzelten bilgilendirici kart tasarımı yaptım. */}
      <section className="detay-ek-bolum">
        <h2 className="bolum-basligi">01 // Efsaneler ve Gerçekler</h2>
        <div className="efsane-grid">
          {/* Efsaneler listesindeki her bir nesneye 'item' ismini ver */}
          {veri.efsaneler.map((item, index) => (
            <div className="efsane-kart" key={index}>
              {/* Yanlış bilgisini kırmızı etiketle göster */}
              <p className="etiket-yanlis">YANLIŞ</p>
              <p>"{item.yanlis}"</p>
              {/* Doğru bilgisini yeşil etiketle göster */}
              <p className="etiket-dogru">DOĞRU</p>
              <p>{item.dogru}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Teknoloji Bölümü */}
      <section className="detay-ek-bolum">
        <h2 className="bolum-basligi">02 // Teknoloji ve Hazırlık</h2>
        <div className="teknoloji-liste">
          {veri.teknolojiler.map((tekno, index) => (
            <div className="teknoloji-item" key={index}>
              <span className="tekno-no">0{index + 1}</span>
              <div>
                <h4>{tekno.ad}</h4>
                <p>{tekno.aciklama}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

const AFET_VERILERI = {
  deprem: {
    baslik: "Deprem",
    altBaslik: "Sarsılmayan Bir Gelecek İçin: Bilinç ve Tedbir Rehberi",
    tanimlar: [
      "Deprem; yer kabuğu içindeki kırılmalar nedeniyle ani olarak ortaya çıkan titreşimlerin, dalgalar halinde yayılarak yeryüzünü sarsması olayıdır.",
      "Türkiye'nin sismik geçmişi incelendiğinde, bu coğrafyanın bir 'deprem ülkesi' olduğu gerçeği kaçınılmazdır. Hazırlıklı olmak hayat kurtarır."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Acil Durum Çantası: İçinde su, temel gıda ve ilk yardım malzemeleri olan bir çanta hazırlayın.",
          "Eşya Sabitleme: Gardırop ve beyaz eşya gibi ağır mobilyaları duvara monte edin.",
          "Vana Bilgisi: Evdeki gaz, su ve elektrik vanalarının yerini ve nasıl kapatılacağını öğrenin.", 
          "Aile Planı: Deprem anında ve sonrasında aile fertleriyle nerede buluşacağınızı planlayın.",
          "Yapı Kontrolü: Binanızın deprem dayanıklılık testini uzman ekiplere yaptırın.",
          "Cam Önlemi: Yataklarınızı cam kenarlarından uzağa yerleştirin.",
          "Eğitim: Temel ilk yardım ve yangın söndürme gibi eğitimlere katılım sağlayın."
        ] 
      },
      { 
        no: "02", 
        baslik: "UYGULAMA: SIRASI", 
        maddeler: [
          "Balkonlardan Uzak Durun: Balkonlar binanın en zayıf halkasıdır, asla buraya çıkmayın.",
          "Çök-Kapan-Tutun: Sağlam bir nesnenin yanına çöküp başınızı koruyarak tutunun.",
          "Asansör Kullanmayın: Sarsıntı anında asansörler düşebilir veya içinde mahsur kalabilirsiniz.",
          "Mutfaktan Kaçının: Raflardan düşecek eşyalar ve gaz sızıntısı riski nedeniyle mutfaktan uzaklaşın.",
          "Merdivenlere Koşmayın: Kaçış sırasında merdivenlerde yığılma ve yaralanma riski yüksektir.",
          "Elektrik ve Gaz: Sarsıntı biter bitmez imkanınız varsa ana vanaları kapatın.",
          "Sakin Kalın: Panik yapmak hatalı kararlar vermenize neden olur, derin nefes alın.",
          "Dışarıdaysanız: Binalardan, elektrik direklerinden ve ağaçlardan uzak açık bir alana gidin."
        ] 
      },
      { 
        no: "03", 
        baslik: "TAHLİYE: SONRASI", 
        maddeler: [
          "SMS Kullanın: Telefon hatlarını meşgul etmemek için haberleşmeyi sadece SMS ile yapın.",
          "Toplanma Alanı:Daha önceden belirlenmiş olan mahalle toplanma alanına gidin.",
          "Radyo Takip: Resmi makamların açıklamalarını takip etmek için pilli radyo kullanın.",
          "Tesisat Kontrolü: Çakmak yakmadan önce gaz kokusu olup olmadığını dikkatlice kontrol edin.",
          "Hasar Tespiti: Binanızda çatlak veya yapısal hasar varsa asla içeri girmeyin.",
          "Yardım Etme: Kendi güvenliğiniz sağlandıktan sonra çevrenizdeki yaralılara destek olun.",
          "Deniz Kıyısından Uzaklaşın: Kıyı bölgelerinde tsunami riski oluşabileceğini unutmayın.",
          "İlaç ve Gıda: Çantanızdaki stokları idareli kullanarak resmi yardımların gelmesini bekleyin."
        ] 
      }
    ],
    haritaIkon: "📍",
    haritaNotu: "Türkiye genelinde 5.5 ve üzeri deprem üretebilecek 485 diri fay hattı bulunmaktadır.",
    efsaneler: [
      { yanlis: "Sarsıntı başlar başlamaz asansöre binip aşağı inmeliyim.", dogru: "Elektrik kesintisi veya mekanik arıza nedeniyle asansörde mahsur kalabilir, hatta asansör boşluğuna düşebilirsiniz. Asansörü asla kullanmayın." },
      { yanlis: "Çelik kapı eşiğinde durursam kapı beni korur.", dogru: "modern binalarda kapı eşikleri taşıyıcı değildir. Ayrıca sarsıntıdan kapı kasılabilir ve parmaklarınız sıkışabilir." },
      { yanlis: "Deprem sırasında kapı eşiğinde durulmalıdır.", dogru: "Kapı eşikleri modern binalarda yük taşıyıcı değildir, güvenli alan sayılmazlar." },
      { yanlis: "Hayvanlar depremi günler öncesinden sezer.", dogru: "Hayvanlar sarsıntıyı insanlardan saniyeler önce hissedebilir ancak günlerce önceden tahmin edemezler." }
    ],
    teknolojiler: [
      { ad: "AFAD Acil", aciklama: "Tek tuşla konum bildirme, sorgulama ve acil yardım çağrısı." },
      { ad: "Google Deprem Uyarı", aciklama: "Android telefonlardaki ivmeölçerler sayesinde sarsıntı gelmeden saniyeler önce uyarı gönderir." },
      { ad: "Güvende miyim?", aciklama: "İnternet bağlantısı olmasa bile ailenize konumunuzu ve durumunuzu SMS ile bildiren uygulama." }
    ]
  },
  sel: {
    baslik: "Sel",
    altBaslik: "Sel Bilinci Rehberi Rehberi",
    tanimlar: [
      "Sel; yağış, kar erimesi veya baraj yıkılması gibi nedenlerle su kütlelerinin ani yayılmasıdır.",
      "Sellerin büyük çoğunluğu ani gelişir. Erken uyarı sistemlerini takip etmek hayati önem taşır."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Risk Sorgulama: Yaşadığınız bölgenin sel ve taşkın risk haritasını kontrol edin.",
          "Yapısal Önlem: Dere yatağına yapılan her bina, sel sularına karşı savunmasız bir hedeftir. Doğal drenaj hatlarını korumak en büyük önlemdir.",
          "Alçak Kat Tahliyesi: Bodrum veya zemin katta yaşıyorsanız önemli eşyalarınızı üst katlara taşıyın.",
          "Kum Torbaları: Suyun giriş yapabileceği kapı ve pencereler için kum torbası hazır bulundurun.",
          "Haberleşme: Yerel yönetimlerin ve meteorolojinin uyarılarını takip edin.",
          "Sigorta: Konut sigortanızın sel ve su baskını teminatını kontrol edin.",
          "Vana Erişimi: Su ve elektrik sigortalarına hızlı erişim için yolları açık tutun.",
          "Gider Kontrolü: Evinizdeki ve sokağınızdaki drenaj hatlarının tıkalı olmadığından emin olun.",
          "Acil Kit: Sel durumunda yanınıza alacağınız çantada su geçirmez poşetler bulundurun."
          
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Yürüyen Su: Sadece 15 cm derinlikteki yürüyen suyun sizi düşürebileceğini unutmayın.",
          "Üst Katlara Çıkın: Su seviyesi yükseliyorsa hızla en güvenli üst kata çıkın.",
          "Elektrik Kesintisi: Su ile temas etme riski olan tüm elektrik bağlantılarını kesin.",
          "Yüzmeyin: Sel suları kanalizasyon ve moloz içerebileceği için asla sel sularında yüzmeyin.",
          "Köprülerden Uzak Durun: Altından hızla su akan köprüler çökme riski taşır.",
          "Çocukları Koruyun: Çocukları asla su birikintilerinin yakınında oyun oynaması için bırakmayın.",
          "Araç Kullanımı: Araç içindeyken su yükseliyorsa aracı bırakıp hemen yüksek bir yere çıkın.",
          "Hijyen: Sel suyuyla temas eden her şeyi mikrop riski nedeniyle imha edin."
        ]
      },
      { 
        no: "03", 
        baslik: "TAHLİYE: SONRASI", 
        maddeler: [
          "Elektrik Kontrolü: Tesisatınız uzman bir elektrikçi tarafından kontrol edilmeden enerjiyi açmayın.",
          "Durgun Su: Durgun sel sularına dokunmayın, elektrik kaçağı veya hastalık riski taşıyabilir.",
          "Hasar Fotoğraflama: Sigorta işlemleri için evdeki hasarı detaylıca fotoğraflayın.",
          "Temizlik: Evinizi temizlerken mutlaka eldiven, maske ve koruyucu bot kullanın.",
          "Yiyecek Kontrolü: Sel suyuyla temas etmiş tüm gıdaları ve ilaçları çöpe atın.",
          "Yerel Bilgi: Su hattının güvenli olduğu ilan edilene kadar şebeke suyunu içmeyin.",
          "Küf Önlemi: Evi havalandırarak küf oluşumunu engellemek için kurutma çalışmalarına başlayın.",
          "Dayanışma: Yerel yardım merkezlerine giderek ihtiyaç duyulan malzemeleri temin edin."
        ]
      }
    ],
    haritaIkon: "🌊",
    haritaNotu: "Türkiye'de her yıl ortalama 50-80 sel olayı yaşanmaktadır. Karadeniz en riskli bölgedir.",
    efsaneler: [
      { yanlis: "Yavaş akan sel suyu tehlikeli değildir.", dogru: "Sadece 60 cm derinliğindeki su bile koca bir kamyonu sürükleyebilir." },
      { yanlis: "Araçla selden kaçmak en hızlı yoldur.", dogru: "30 cm su aracınızın kontrolünü kaybetmenize, 60 cm su ise aracın sürüklenmesine neden olur." },
      { yanlis: "Selden sonra evdeki su ile temizlik yapılabilir.", dogru: "Sel suları kanalizasyon ve kimyasal atık taşıyabilir, asla kullanılmamalıdır." },
      { yanlis: "Sel sadece nehir kenarlarında olur.", dogru: "Aşırı yağışlarda şehir altyapısı yetersiz kalarak her noktada su baskını oluşturabilir." }
    ],
    teknolojiler: [
      { ad: "AFAD Erken Uyarı", aciklama: "Anlık sel ve taşkın risklerini bölge bazlı olarak bildiren sistem." },
      { ad: "Akıllı Su Sensörleri", aciklama: "Evin sızdırmazlık noktalarına yerleştirilen ve su temasında alarm veren cihazlar." },
      { ad: "Meteoroloji MGM", aciklama: "Hava durumu ve ani yağış risklerini saatlik olarak takip edebileceğiniz resmi uygulama." }
    ]
  },
  kuraklik: {
    baslik: "Kuraklık",
    altBaslik: "Suya Veda Etmeden: Tasarruf Bilinci",
    tanimlar: [
      "Kuraklık; bir bölgedeki nem miktarının geçici dengesizliğinden kaynaklanan ve su kıtlığına yol açan doğal bir olaydır.",
      "İklim değişikliği ile birlikte su kaynaklarımızı korumak artık bir tercih değil, zorunluluktur."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Tasarruflu Başlıklar: Musluklarınıza ve duş başlıklarınıza su tasarruf aparatları takın.",
          "Yağmur Hasadı: Bahçe sulaması için yağmur sularını biriktirecek depolar kurun.",
          "Sızıntı Kontrolü: Evdeki damlatan muslukları ve sızdıran sifonları hemen tamir edin.",
          "Bitki Seçimi: Bahçenizde bölgenin iklimine uygun, az su isteyen bitkiler yetiştirin.",
          "Eğitim: Aile bireylerine diş fırçalarken musluğu kapatma alışkanlığı kazandırın.",
          "Bulaşık/Çamaşır: Makineleri sadece tam doluyken ve ekonomik modda çalıştırın.",
          "Gri Su Kullanımı: Mutfaktaki temiz yıkama sularını çiçek sulamak için tekrar kullanın.",
          "Bilinçli Tüketim: Su ayak izinizi azaltacak ürünleri tercih etmeye başlayın."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Su Önceliği: Mevcut suyunuzu içme, yemek pişirme ve temel temizlik için önceliklendirin.",
          "Kısıtlamalara Uyun: Yerel yönetimlerin su kullanımı konusundaki yasak ve kısıtlamalarına uyun.",
          "Bahçe Sulama: Bitkilerinizi sadece akşam geç saatlerde veya sabah erken saatlerde sulayın.",
          "Araç Yıkama: Kuraklık döneminde araçlarınızı hortumla yıkamaktan kaçının, kova kullanın.",
          "Buharlaşma Önlemi: Havuzunuz varsa üzerini örterek suyun buharlaşmasını engelleyin.",
          "Atık Yağlar: Yağları lavaboya dökmeyin, bir litre yağ milyonlarca litre suyu kirletir.",
          "Dayanışma: Su kesintilerinde komşularınızla koordineli hareket ederek stoklarınızı paylaşın."
        ]
      },
      { 
        no: "03", 
        baslik: "İYİLEŞTİRME: SONRASI", 
        maddeler: [
          "Toprak Verimliliği: Kuruyan toprakları canlandırmak için doğal gübreleme yöntemleri kullanın.",
          "Ağaçlandırma: Bölgenizdeki ağaçlandırma çalışmalarına katılarak nem döngüsünü destekleyin.",
          "Sürdürülebilirlik: Kuraklık geçse bile edindiğiniz tasarruf alışkanlıklarını terk etmeyin.",
          "Altyapı Yenileme: Belediye ile iletişime geçerek bölgedeki su kaçaklarını raporlayın.",
          "Gelecek Planı: Bir sonraki olası kuraklık dönemi için su depolama kapasitenizi artırın.",
          "Yerel Tarım: Çok su tüketen tarım ürünleri yerine alternatif ürünlere yönelin.",
          "Veri Takibi: Bölgenizdeki baraj doluluk oranlarını düzenli olarak takip edin.",
          "Bilinçlendirme: Okullarda ve topluluklarda suyun önemi hakkında sunumlar yapın."
        ]
      }
    ],
    haritaIkon: "☀️",
    haritaNotu: "Türkiye yarı kurak bir iklim kuşağındadır. Kişi başına düşen su miktarı her yıl azalmaktadır.",
    efsaneler: [
      { yanlis: "Türkiye su zengini bir ülkedir.", dogru: "Türkiye su stresi çeken bir ülkedir ve su fakiri olma sınırındadır." },
      { yanlis: "Musluğu açık bırakmak çok su kaybettirmez.", dogru: "Dakikada sızdıran bir musluk yılda binlerce litre suyu boşa harcar." },
      { yanlis: "Yeraltı suları sınırsızdır.", dogru: "Yeraltı sularının yenilenmesi yüzyıllar sürebilir ve kontrolsüz kullanım felakettir." },
      { yanlis: "Sadece büyük fabrikalar su tasarrufu yapmalıdır.", dogru: "Bireysel tasarruflar birleştiğinde şehirlerin su ihtiyacını karşılayacak seviyeye ulaşır." }
    ],
    teknolojiler: [
      { ad: "Akıllı Sayaçlar", aciklama: "Su kullanımınızı anlık takip eden ve sızıntı durumunda telefonunuza bildirim gönderen sistemler." },
      { ad: "Damlama Sulama", aciklama: "Tarımsal ve bahçe sulamada suyun doğrudan bitki köküne verilmesini sağlayan verimli yöntem." },
      { ad: "Su Ayak İzi Hesaplayıcı", aciklama: "Günlük alışkanlıklarınızın ne kadar su tükettiğini gösteren mobil uygulamalar." }
    ]
  },
  patlama: {
    baslik: "Volkanik Patlama",
    altBaslik: "Magma ve Korunma Rehberi",
    tanimlar: [
      "Volkanik patlama; yer kabuğunun altındaki magmanın gazlarla birlikte yer yüzüne çıkması olayıdır.",
      "Türkiye'de aktif yanardağ bulunmasa da, sönmüş yanardağların çevresindeki jeolojik riskler takip edilmelidir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Risk Alanları: Sönmüş de olsa yanardağ yakınındaki yerleşim yerlerinin risk haritasını öğrenin.",
          "Koruyucu Ekipman: Kül yağmuruna karşı toz maskesi, deniz gözlüğü ve uzun kollu giysiler edinin.",
          "Hava Filtreleri: Evinizdeki havalandırma sistemleri için yedek filtreler bulundurun.",
          "İletişim: Tahliye yollarını ve en yakın güvenli bölgeleri önceden belirleyin.",
          "Acil Kit: Çantanızda özellikle göz ve solunum koruyucu malzemelerin olduğundan emin olun.",
          "Hayvan Koruması: Evcil ve çiftlik hayvanlarınız için kapalı barınak planları yapın.",
          "Yedek Su: Küllerin su kaynaklarını kirletme riskine karşı kapalı kaplarda su depolayın.",
          "Bilgilendirme: Volkanik faaliyet izleme istasyonlarının verilerini takip edin."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Rüzgar Yönü: Kül bulutlarının rüzgarla taşınacağını unutmayın, rüzgarı arkanıza alarak kaçın.",
          "Kapalı Alan: Patlama anında mümkünse iç mekanlarda kalın ve tüm pencereleri kapatın.",
          "Maske Kullanımı: Dışarı çıkmak zorundaysanız mutlaka N95 maske veya ıslak bez kullanın.",
          "Çatılar: Biriken kül ağırlaşarak çatıları çökertebilir, güvenli değilse çatının altında durmayın.",
          "Vadi ve Dere Yatakları: Çamur akıntıları (lahar) buralarda hızla ilerler, yüksek yerlere çıkın.",
          "Araç Kullanımı: Kül motoru bozabilir, görüşü kapatabilir; zorunlu değilse araç kullanmayın.",
          "Cilt Koruması: Külün tahriş edici etkisinden korunmak için cildinizi tamamen örtün.",
          "Resmi Uyarı: Sadece yetkililerin yönlendirdiği tahliye rotalarını kullanın."
        ]
      },
      { 
        no: "03", 
        baslik: "İYİLEŞTİRME: SONRASI", 
        maddeler: [
          "Kül Temizliği: Çatıdaki külleri temizlerken kendinizi koruyun, kül ıslanınca çok ağırlaşır.",
          "Hava Kontrolü: İç mekanı havalandırmadan önce dışarıdaki tozun çöktüğünden emin olun.",
          "Su Kaynakları: Açıkta kalan suları içmeyin, analiz edilmesini bekleyin.",
          "Bitki Örtüsü: Kül altındaki bitkileri yıkayarak temizleyin, kül besleyici olsa da başta boğucu olabilir.",
          "Elektronik Cihazlar: Hassas elektronik cihazları temizlemeden çalıştırmayın, kül aşındırıcıdır.",
          "Sağlık Takibi: Solunum yolu şikayetleriniz artarsa derhal bir sağlık kuruluşuna başvurun.",
          "Altyapı: Elektrik hatlarındaki kül birikintileri kısa devreye yol açabilir, dikkatli olun.",
          
        ]
      }
    ],
    haritaIkon: "🌋",
    haritaNotu: "Türkiye'de Ağrı, Nemrut ve Erciyes gibi sönmüş yanardağlar bulunmaktadır.",
    efsaneler: [
      { yanlis: "Sönmüş yanardağlar asla tekrar patlamaz.", dogru: "Jeolojik zaman ölçeğinde binlerce yıl sonra tekrar aktif hale gelebilirler." },
      { yanlis: "Volkanik kül, şömine külü gibi yumuşaktır.", dogru: "Volkanik kül aslında küçük cam ve kaya parçacıklarıdır, akciğerlere çok zararlıdır." },
      { yanlis: "Lavdan kaçmak imkansızdır.", dogru: "Lav akıntıları genellikle yavaştır, asıl tehlike gazlar ve çamur akıntılarıdır." },
      { yanlis: "Volkanik patlamalar sadece sıcak iklimlerde olur.", dogru: "Yanardağlar her iklim kuşağında, hatta buzulların altında bile bulunabilir." }
    ],
    teknolojiler: [
      { ad: "Sismograflar", aciklama: "Magma hareketlerinin neden olduğu küçük sarsıntıları önceden tespit eden hassas cihazlar." },
      { ad: "Termal Uydu Görüntüleme", aciklama: "Kritik sıcaklık artışlarını uzaydan takip ederek erken uyarı veren teknoloji." },
      { ad: "Gaz Sensörleri", aciklama: "Yanardağ ağzından çıkan kükürt ve karbondioksit miktarını ölçen sensörler." }
    ]
  },
  yangin: {
    baslik: "Yangın",
    altBaslik: "Orman ve Ev Güvenliği",
    tanimlar: [
      "Yangın; kontrol dışına çıkan yanma olayıdır ve saniyeler içinde devasa alanlara yayılabilir.",
      "Yangınların büyük bir kısmı insan ihmali kaynaklıdır; tedbir almak en etkili söndürme yöntemidir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Duman Dedektörü: Evinizin her katına ve yatak odası yakınlarına duman dedektörü takın.",
          "Söndürme Cihazı: Mutfağınızda ve aracınızda mutlaka güncel bir yangın tüpü bulundurun.",
          "Tahliye Planı: Evden iki farklı çıkış rotası belirleyin ve ailece tatbikat yapın.",
          "Yanıcı Maddeler: Temizlik malzemelerini ve gaz tüplerini ısı kaynaklarından uzak tutun.",
          "Elektrik Tesisatı: Eskimiş kabloları ve aşırı yüklenmiş prizleri kontrol ettirip yenileyin.",
          "Orman Temizliği: Bahçenizdeki kuru otları temizleyerek ateş sıçrama riskini azaltın.",
          "Önemli Belgeler: Tapu, kimlik gibi belgeleri su ve ateş geçirmez bir çantada saklayın.",
          "İtfaiye Erişimi: Evinize giden yolların itfaiye araçları için açık olduğundan emin olun."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Yere Yakın Durun: Duman yukarı yükselir, temiz hava için emekleyerek ilerleyin.",
          "Kapı Kontrolü: Bir kapıyı açmadan önce elinizin tersiyle sıcaklığını kontrol edin.",
          "Giysi Tutuşursa: Dur-Yat-Yuvarlan kuralını uygulayarak alevleri söndürün.",
          "Asansör Kullanmayın: Yangın anında elektrik kesilebilir ve asansörde mahsur kalabilirsiniz.",
          "Haber Verin: Güvenli bir alana çıkar çıkmaz 112 Acil Çağrı merkezini arayın.",
          "Islak Bez: Ağzınızı ve burnunuzu ıslak bir bezle kapatarak duman solumayı azaltın.",
          "Eşya Kurtarmayın: Can güvenliğiniz her şeyden önemlidir, eşya almak için geri dönmeyin.",
          "Dışarıdaysanız: Rüzgarı arkanıza alarak yangın bölgesinden hızla uzaklaşın."
        ]
      },
      { 
        no: "03", 
        baslik: "İYİLEŞTİRME: SONRASI", 
        maddeler: [
          "Yetkili Onayı: İtfaiye güvenli demeden hasarlı binaya asla giriş yapmayın.",
          "Tesisat Kontrolü: Elektrik ve gaz tesisatı uzmanlarca onarılmadan sistemi açmayın.",
          "Soğutma Çalışması: Sönmüş görünen alanlarda gizli ateş olabileceği için dikkatli olun.",
          "Eşya Kullanımı: Yangından zarar görmüş gıda ve ilaçları kesinlikle kullanmayın.",
          "Hasar Raporu: Sigorta şirketini arayarak hasar tespiti için talep oluşturun.",
          "Su Baskını Kontrolü: Söndürme sırasında kullanılan suyun yapıya zarar verip vermediğine bakın.",
          "Gelecek Tedbiri: Yangın nedenini öğrenerek aynı hatanın tekrarlanmaması için önlem alın."
        ]
      }
    ],
    haritaIkon: "🔥",
    haritaNotu: "Türkiye'de özellikle Ege ve Akdeniz bölgeleri yaz aylarında yüksek orman yangını riski taşır.",
    efsaneler: [
      { yanlis: "Yangın anında en güvenli yer banyodur.", dogru: "Su baskını ve duman boğulması riski nedeniyle banyoya saklanmak yanlıştır." },
      { yanlis: "Yangınlar genellikle alev nedeniyle can kaybına yol açar.", dogru: "Ölümlerin çoğu alevden değil, zehirli duman solunması nedeniyle gerçekleşir." },
      { yanlis: "Küçük bir yangın tüpü her şeyi söndürür.", dogru: "Yangın tüpleri sadece başlangıç aşamasındaki küçük yangınlar içindir." },
      { yanlis: "Orman yangınları sadece cam kırıklarından çıkar.", dogru: "Cam kırıkları bir etkendir ancak en büyük neden anız yakma ve söndürülmemiş sigaralardır." }
    ],
    teknolojiler: [
      { ad: "İHA Takibi", aciklama: "Bayraktar gibi İHA'lar ormanlarımızı 7/24 tarayarak dumanı anında tespit eder." },
      { ad: "Akıllı Duman Dedektörleri", aciklama: "Evde duman algıladığında sadece alarm çalmakla kalmayıp telefonunuza arama yapan sistemler." },
      { ad: "Yangın Söndürme Topları", aciklama: "Alevle temas ettiğinde patlayarak çevresindeki yangını söndüren otomatik toplar." }
    ]
  },
  cig: {
    baslik: "Çığ",
    altBaslik: "Kar Kütleleri ve Güvenlik",
    tanimlar: [
      "Çığ; yamaçlarda biriken kar kütlesinin yer çekimi etkisiyle hızla aşağı kaymasıdır.",
      "Çığ genellikle saniyeler içinde gerçekleşir ve çok güçlü bir hava basıncıyla birlikte gelir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Bölge Takibi: Kış aylarında çığ riski olan bölgelerin haritalarını ve uyarılarını takip edin.",
          "Hava Durumu: Yoğun kar yağışı ve ani sıcaklık artışlarının çığ riskini artırdığını bilin.",
          "Ekipman: Dağlık alanlara giderken yanınızda mutlaka çığ sondası ve kürek bulundurun.",
          "Eğitim: Karda yürüyüş ve çığ güvenliği konusunda temel eğitimler alın.",
          "Sinyal Cihazı: Kar altında yerinizi belirleyecek olan ARTVA (sinyal verici) cihazı taşıyın.",
          "Grup Halinde Hareket: Çığ bölgelerinden asla tek başınıza geçmeyin.",
          "Rota Seçimi: Yamaçların rüzgar altı kısımlarının daha riskli olduğunu unutmayın.",
          "İletişim: Gideceğiniz rotayı ve tahmini dönüş saatinizi mutlaka birilerine bildirin."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Hızla Kaçın: Çığın geliş yönünü belirleyin ve yanlara doğru hızla uzaklaşın.",
          "Eşyaları Atın: Sizi yavaşlatacak sırt çantası ve kayak takımlarından kurtulun.",
          "Yüzme Hareketi: Karın içinde kalmamak için kollarınızla yüzme hareketi yaparak yüzeyde kalın.",
          "Hava Boşluğu: Kar altında kalırsanız ağzınızın önünde ellerinizle bir hava boşluğu yaratın.",
          "Enerji Tasarrufu: Sürekli bağırmak yerine, kurtarma ekiplerini duyduğunuzda ses verin.",
          "Yön Belirleme: Kar altındayken tükürerek yer çekimi sayesinde yukarısının neresi olduğunu anlayın.",
          "Sakin Kalın: Panik solunumunuzu hızlandırır ve sınırlı oksijeni çabuk tüketmenize neden olur.",
          "Ağzı Kapatın: Karın ağzınıza ve burnunuza dolmasını engellemek için ağzınızı sıkıca kapatın."
        ]
      },
      { 
        no: "03", 
        baslik: "İYİLEŞTİRME: SONRASI", 
        maddeler: [
          "Hipotermi Kontrolü: Kurtarılan kişiyi yavaşça ısıtın, ani sıcaklık değişiminden kaçının.",
          "Haberleşme: 112 Acil hattına yaralı sayısı ve durumu hakkında net bilgi verin.",
          "İkincil Çığ: Bir çığ düştüğünde artçı çığların gelebileceğini unutmayın, bölgeyi terk edin.",
          "İlk Yardım: Yaralıların solunum yolunu kontrol edin ve gerekirse temel yaşam desteği verin.",
          "Ekipman Bakımı: Zarar gören güvenlik ekipmanlarını yenileyerek bir sonraki döneme hazır olun.",
          "Raporlama: Yaşanan çığ olayını yerel afet yönetim merkezine detaylarıyla bildirin.",
          "Deneyim Paylaşımı: Diğer doğa sporcularını riskli bölgeler hakkında bilgilendirin."
        ]
      }
    ],
    haritaIkon: "❄️",
    haritaNotu: "Doğu Anadolu Bölgesi, dik yamaçları ve yoğun kar yağışı nedeniyle çığ riski en yüksek bölgemizdir.",
    efsaneler: [
      { yanlis: "Bağırmak çığ düşmesine neden olur.", dogru: "İnsan sesi nadiren çığ tetikler, asıl neden kar üzerindeki ağırlık ve rüzgardır." },
      { yanlis: "Çığ sadece kışın olur.", dogru: "Bahar aylarındaki karların erimesiyle oluşan 'ıslak kar çığları' çok tehlikelidir." },
      { yanlis: "Kar altında oksijen bitmez.", dogru: "Karın içindeki hava sınırlıdır ve asıl sorun karın buzlaşarak nefes almayı engellemesidir." },
      { yanlis: "Çam ağaçları olan yamaçlarda çığ olmaz.", dogru: "Eğer ağaçlar seyrekse kar kütlesi ağaçların arasından hızla akıp gidebilir." }
    ],
    teknolojiler: [
      { ad: "ARTVA Cihazı", aciklama: "Kar altında kalan kişiyi metrelerce derinden bulmaya yarayan radyo sinyal cihazı." },
      { ad: "Çığ Hava Yastığı", aciklama: "Çığ anında tetiklendiğinde şişerek kişinin karın yüzeyinde kalmasını sağlayan sırt çantası." },
      { ad: "Radar Sensörleri", aciklama: "Kritik yamaçlardaki kar birikmesini uzaktan ölçerek patlatma ile kontrollü çığ oluşturan sistemler." }
    ]
  },
  heyelan: {
    baslik: "Heyelan",
    altBaslik: "Toprak Kayması ve Önlemler",
    tanimlar: [
      "Heyelan; toprak, kaya veya döküntü yığınlarının yer çekimi, eğim ve su gibi etkilerle yamaç aşağı hızla hareket etmesidir.",
      "Türkiye'de özellikle yağışın bol, eğimin fazla olduğu Karadeniz bölgesinde sıkça karşılaşılan, can ve mal kaybına yol açabilen ciddi bir afettir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Drenaj Kanalları: Evinizin çevresinde suyun birikmesini engelleyecek drenaj kanalları oluşturun.",
          "İstinat Duvarı: Eğimli bölgelerde toprağı tutması için mühendislik onaylı istinat duvarları yaptırın.",
          "Bitki Örtüsü: Yamaçlardaki ağaçları koruyun; ağaç kökleri toprağı bir arada tutan doğal ağlardır.",
          "Sızıntı Takibi: Bahçenizde veya yamaçta aniden oluşan su sızıntılarını veya göllenmeleri ciddiye alın.",
          "Yapısal Gözlem: Kapı ve pencerelerin aniden sıkışması veya duvarlardaki yeni çatlaklar heyelan habercisi olabilir.",
          "Risk Haritası: Yaşadığınız bölgenin heyelan risk bölgesinde olup olmadığını AFAD üzerinden kontrol edin.",
          "Tahliye Rotası: Heyelan anında kaçabileceğiniz en güvenli ve yüksek rotayı önceden belirleyin.",
          "Sigorta: Konut sigortanızın yer kayması ve heyelan risklerini kapsadığından emin olun."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Binadan Uzaklaşın: Heyelan başladığında binayı terk edebiliyorsanız hızla güvenli alana kaçın.",
          "İçerideyseniz: Binadan çıkamıyorsanız sağlam bir eşyanın yanında cenin pozisyonu alarak başınızı koruyun.",
          "Gürültüyü Dinleyin: Ağaç çatırması, kaya çarpması gibi gürültüler heyelanın yaklaştığını gösterir.",
          "Üst Katlara Çıkın: Heyelan sırasında binanın alt katları daha fazla risk altındadır, yukarı katlara ilerleyin.",
          "Dere Yataklarından Kaçın: Çamur akıntıları vadi ve dere yataklarında çok hızlı ilerler, yamaçlara tırmanın.",
          "Elektrik ve Gaz: İmkanınız varsa saniyeler içinde ana şalter ve vanaları kapatıp öyle korunun.",
          "Cenin Pozisyonu: Karşı koyamayacağınız bir durumdaysanız başınızı koruyup vücudunuzu küçültün.",
          "Dışarıdaysanız: Heyelan yolundan uzaklaşmak için dik değil, yana doğru koşarak kaçın."
        ]
      },
      { 
        no: "03", 
        baslik: "İYİLEŞTİRME: SONRASI", 
        maddeler: [
          "İkincil Kayma: Bir heyelan sonrası toprağın hala hareketli olabileceğini unutmayın, bölgeye dönmeyin.",
          "Tesisat Kontrolü: Gaz, su ve elektrik hatlarında sızıntı veya kopma olup olmadığını yetkililere kontrol ettirin.",
          "Hasar Tespiti: Binanızda gözle görülür bir hasar olmasa bile uzman onayı almadan içeri girmeyin.",
          "Yol Durumu: Heyelan nedeniyle kapanan yolların açılması için yerel yönetimle iletişimde kalın.",
          "Psikolojik Destek: Afet sonrası yaşanan stres ve kaygı için profesyonel yardım almaktan çekinmeyin.",
          "Ağaçlandırma: Bölgenin tekrar güvenli hale gelmesi için ağaçlandırma çalışmalarına destek verin.",
          "İhbar Etme: Heyelan bölgesindeki elektrik direkleri veya ağaçların durumunu ekiplere bildirin.",
          "Dayanışma: Mağdur olan komşularınızla koordineli hareket ederek yardımlaşma ağı kurun."
        ]
      }
    ],
    haritaIkon: "⛰️",
    haritaNotu: "Doğu Karadeniz Bölgesi, eğimli yapısı ve yüksek yağış miktarıyla Türkiye'de heyelan riskinin en yüksek olduğu alandır.",
    efsaneler: [
      { yanlis: "Ağaçlık alanlarda asla heyelan olmaz.", dogru: "Ağaçlar riski azaltır ancak aşırı yağışlarda ağaçlı yamaçlar da kayabilir." },
      { yanlis: "Heyelan sadece dik dağlarda olur.", dogru: "Hafif eğimli arazilerde bile zemin yapısı bozuksa toprak kayması yaşanabilir." },
      { yanlis: "Heyelan başladığı an duyulur.", dogru: "Bazı heyelanlar çok sessiz başlar, sadece toprağın şişmesi veya çatlaklarla fark edilir." },
      { yanlis: "Kayan toprağın önüne engel koyarak durdurabiliriz.", dogru: "Binlerce ton toprağın gücünü bireysel engellerle durdurmak imkansızdır, sadece kaçılmalıdır." }
    ],
    teknolojiler: [
      { ad: "Eğim Ölçerler (Inclinometer)", aciklama: "Toprağın derinliklerindeki en küçük hareketleri bile tespit ederek erken uyarı veren cihazlar." },
      { ad: "Uydu Gözlem Sistemleri", aciklama: "Yeryüzündeki milimetrik çökmeleri uzaydan takip ederek riskli bölgeleri belirleyen teknoloji." },
      { ad: "Zemin Nem Sensörleri", aciklama: "Toprağın suya doyma oranını ölçerek heyelan olasılığının arttığını haber veren sensörler." }
    ]
  },
  hortum: {
    baslik: "Hortum",
    altBaslik: "Şiddetli Rüzgar ve Korunma",
    tanimlar: [
      "Hortum; bulutlardan yere kadar uzanan, kendi ekseni etrafında hızla dönen bir hava sütunudur.",
      "Genellikle gök gürültülü fırtınalar sırasında oluşur ve geçtiği yollardaki her şeyi yıkıp geçebilir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Güvenli Oda: Evinizde penceresiz, alt katlarda veya merdiven boşluğu gibi sağlam bir alan belirleyin.",
          "Bahçe Düzeni: Bahçedeki masa, sandalye ve saksı gibi uçabilecek eşyaları sabitleyin.",
          "Pencere Koruması: Şiddetli rüzgarda camların patlamasını engellemek için kepenk veya kalın perdeler kullanın.",
          "Haber Takibi: Meteorolojik uyarıları ve 'Hortum Gözlemi' bildirimlerini anlık takip edin."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Merkeze Kaçın: Penceresiz, iç taraftaki en küçük odaya (genelde banyo veya koridor) gidin.",
          "Yere Yatın: Başınızı ellerinizle koruyarak yere yatın ve mümkünse üzerinizi bir battaniye veya yatakla örtün.",
          "Araçtan Çıkın: Hortum anında araç içinde durmak çok tehlikelidir; aracı bırakıp bir çukura yatın.",
          "Köprü Altından Kaçın: Köprü altları rüzgarın şiddetini artırır (venturi etkisi), buralara saklanmayın."
        ]
      },
      { 
        no: "03", 
        baslik: "TAHLİYE: SONRASI", 
        maddeler: [
          "Hatlara Dikkat: Kopan elektrik hatlarından ve gaz sızıntılarından mutlaka uzak durun.",
          "Yardım: Sadece kendiniz güvendeyseniz yaralılara yardım edin ve 112'yi bilgilendirin.",
          "Enkaz Kontrolü: Yıkılan binaların enkazına girmeyin, çökme riski devam edebilir.",
          "Durum Bildirimi: Ailenize ve yetkililere güvende olduğunuzu kısa bir SMS ile bildirin."
        ]
      }
    ],
    haritaIkon: "🌪️",
    haritaNotu: "Türkiye'de hortum olayları son yıllarda özellikle Antalya, Mersin ve İzmir kıyılarında artış göstermektedir.",
    efsaneler: [
      { yanlis: "Hortum sırasında pencereleri açmak basıncı dengeler.", dogru: "Pencereleri açmak rüzgarın içeri girmesine ve çatının uçmasına neden olur. Kapalı tutun." },
      { yanlis: "Hortum nehirleri veya gölleri geçemez.", dogru: "Hortumlar su üzerinde de ilerleyebilir ve daha tehlikeli hale gelebilir." },
      { yanlis: "En güvenli yer odanın köşesidir.", dogru: "En güvenli yer pencerelerden uzak, binanın en orta ve alt kısmındaki alandır." }
    ],
    teknolojiler: [
      { ad: "Doppler Radarları", aciklama: "Hava hareketlerini ve dönüş hızını takip ederek hortum oluşumunu önceden sezen radarlar." },
      { ad: "Hortum Sirenleri", aciklama: "Bazı bölgelerde kurulu olan ve hortum yaklaştığında tüm yerleşimi uyaran yüksek sesli sistemler." }
    ]
  },
  firtina: {
    baslik: "Fırtına",
    altBaslik: "Rüzgar ve Yağış Güvenliği",
    tanimlar: [
      "Fırtına; rüzgarın saatte 60 km ve üzerinde hızla estiği, genellikle yağmur, kar veya dolu ile birlikte görülen hava olayıdır.",
      "Çatı uçmaları, ağaç devrilmeleri ve ulaşımda aksamalar fırtınanın en sık görülen etkileridir."
    ],
    stratejiler: [
      { 
        no: "01", 
        baslik: "HAZIRLIK: ÖNCESİ", 
        maddeler: [
          "Çatı Kontrolü: Gevşek kiremitleri sabitleyin ve bacaların sağlam olduğundan emin olun.",
          "Ağaç Bakımı: Evinize çok yakın olan ve devrilme riski taşıyan kurumuş ağaç dallarını budayın.",
          "Enerji Hazırlığı: Elektrik kesintilerine karşı fener, yedek pil ve powerbank hazırlayın.",
          "Tahliye Kanalları: Balkon ve teras giderlerini temizleyerek su birikmesini engelleyin."
        ]
      },
      { 
        no: "02", 
        baslik: "MÜDAHALE: SIRASI", 
        maddeler: [
          "Dışarı Çıkmayın: Zorunlu olmadıkça fırtına dinene kadar kapalı mekanlarda kalın.",
          "Pencereden Uzak Durun: Şiddetli rüzgarda kırılan camlar ciddi yaralanmalara yol açabilir.",
          "Araç Güvenliği: Aracınızı ağaçlardan, reklam panolarından ve inşaat iskelelerinden uzağa park edin.",
          "Denizciler İçin: Denizdeyseniz en yakın limana sığının veya kıyıdan açığa, dalgaları karşılayarak ilerleyin."
        ]
      },
      { 
        no: "03", 
        baslik: "TAHLİYE: SONRASI", 
        maddeler: [
          "İkincil Tehlikeler: Fırtına bitse bile gevşeyen dallar veya tabelalar düşebilir, dikkatli yürüyün.",
          "Elektrik Tesisatı: Islanan elektrikli cihazları kurutmadan ve kontrol etmeden çalıştırmayın.",
          "Belediye Bildirimi: Devrilen ağaçları ve kopan telleri belediyenin ilgili birimlerine raporlayın.",
          "Çatı Hasarı: Çatıdaki hasarı onarmak için hava tamamen düzelene kadar bekleyin."
        ]
      }
    ],
    haritaIkon: "🌩️",
    haritaNotu: "Türkiye'de özellikle Marmara ve Ege bölgeleri, Lodos fırtınalarının etkisiyle sık sık risk altına girmektedir.",
    efsaneler: [
      { yanlis: "Sadece yaz fırtınaları tehlikelidir.", dogru: "Kış fırtınaları (karla karışık) donma riski ve çığ nedeniyle daha tehlikeli olabilir." },
      { yanlis: "Ağaç altına sığınmak yağmurdan korur.", dogru: "Ağaçlar yıldırım çekme ve devrilme riski nedeniyle fırtınada en tehlikeli yerlerdir." },
      { yanlis: "Fırtına bitince hemen dışarı çıkılabilir.", dogru: "Fırtınanın 'gözü' (sessiz anı) geçiyor olabilir; rüzgarın tamamen dindiğinden emin olun." }
    ],
    teknolojiler: [
      { ad: "Anemometreler", aciklama: "Rüzgar hızını ve yönünü ölçerek hava durumu istasyonlarına veri sağlayan cihazlar." },
      { ad: "Yıldırım Takip Sistemleri", aciklama: "Fırtına bulutlarındaki elektrik yükünü takip ederek yıldırım düşme riskini haritalandıran teknoloji." }
    ]
  }
};
export default AfetDetay;