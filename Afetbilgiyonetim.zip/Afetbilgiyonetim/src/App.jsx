import React, { useState } from 'react';
import Anasayfa from './pages/Anasayfa'; 
import CerezBildirimi from './components/cerezBildirimi';
import Footer from './components/Footer';
import Oyunlar from './components/Oyun';
import AfetDetay from './components/AfetDetay';
import Giris from './components/GirisYap';
import PortalDetay from './components/PortalDetay';
import KullaniciPaneli from './components/KullaniciPaneli'; 
import Navbar from './components/Navbar'; 
// Dosyalarımı burada import ediyoum
function App() {
  const [aktifSayfa, setAktifSayfa] = useState('anasayfa');  //uygulamanın ilk açıldığında hangi sayfada aktif olduğunu tutuyor.
  const [secilenAfet, setSecilenAfet] = useState('');    //kullanıcı bir ögeye tıkladığında hangi seçilen afet olduğunu tutuyor
  const [portalIcerigi, setPortalIcerigi] = useState('');   //navbarda bilgi portalında hangisine tıklandığını tutuyor.

//  SAYFA DEĞİŞTİRME KOMUTLARI
// kullanıcı hangi karta tıkladıysa o afetin ismini al ve kaydet. seçilen aktif sayfanın detayını aç.
//  = (isim) =>: arrow fonk.

  const detayAc = (isim) => {
    setSecilenAfet(isim); 
    setAktifSayfa('detay'); 
  };
//  SEÇİLEN AFETTEN SONRA TEKRAR ANASAYFAYA DÖNMEYİ SAĞLIYOR
  const kapatDetay = () => {
    setAktifSayfa('anasayfa');
    setSecilenAfet('');
  };

  return (
    <div className="App">
      {/* NAVBAR SADECE ANASAYFADA VE PORTAL AÇIKKEN GÖRÜNECEK */}
      {(aktifSayfa === 'anasayfa' || aktifSayfa === 'portal') && (
        <Navbar 
          setAktifSayfa={setAktifSayfa} 
          setPortalIcerigi={setPortalIcerigi} 
        />
      )}

      {/* EĞER AKTİFSAYFA ANASAYFA İSE AŞAĞIDAKİLERİ GÖSTER (ÇEREZ BİLDİRİMİNİ FOOTER KISMINI ANASAYFADA GÖSTER) */}
      {aktifSayfa === 'anasayfa' && (
        <>
          <Anasayfa setAktifSayfa={setAktifSayfa} detayAc={detayAc} /> 
          <CerezBildirimi />
          <Footer />
        </>
      )}

     {/* GİRİŞ YAP SAYFASI: Eğer aktifSayfa 'giris' ise sadece giriş formunu göster */}
      {aktifSayfa === 'giris' && (
        <Giris setAktifSayfa={setAktifSayfa} />
      )}

      {/* AFET DETAYLARI:hangi afetin seçildiğini ve kapat butonuna basında çalışacak fonksiyonu gösterir. */}
      {aktifSayfa === 'detay' && (
        <AfetDetay 
          tip={secilenAfet}
          kapatFonksiyonu={kapatDetay} 
        />
      )}

      {/* KULLANICI PANELİ */}
      {aktifSayfa === 'panel' && (
        <KullaniciPaneli setAktifSayfa={setAktifSayfa} />
      )}
        
      {/* menüden veya navbardan bir detay içeriğine basarsa görünür ve kapatma butonuna basınca fonksşyon çalışır anasayfaya döner */}
      {aktifSayfa === 'portal' && (
        <PortalDetay 
          icerik={portalIcerigi} 
          kapatFonksiyonu={() => setAktifSayfa('anasayfa')} 
        />
      )}
   {aktifSayfa === 'oyunlar' && <Oyunlar />}
      
    </div>
  );
}

export default App;